/* ============================================================
   PDL EMAIL INTELLIGENCE — FRONTEND BEHAVIOUR
   Uses the existing backend endpoints; no backend configuration
   or API contract is changed.
   ============================================================ */

document.addEventListener("DOMContentLoaded", function () {
  initTheme();
  initIstClock();

  const sidebar = document.getElementById("sidebar");
  const mobileMenu = document.getElementById("mobileMenu");
  const overlay = document.getElementById("sidebarOverlay");

  function closeSidebar() {
    if (!sidebar) return;
    sidebar.classList.remove("open");
  }

  if (mobileMenu && sidebar) {
    mobileMenu.addEventListener("click", function () {
      sidebar.classList.toggle("open");
    });
  }

  if (overlay) {
    overlay.addEventListener("click", closeSidebar);
  }

  document.querySelectorAll(".nav-link").forEach(function (link) {
    link.addEventListener("click", function () {
      if (window.innerWidth <= 900) closeSidebar();
    });
  });

  const syncButton = document.getElementById("sync-outlook");
  if (syncButton) {
    syncButton.addEventListener("click", syncOutlook);
  }

  document.querySelectorAll(".flash").forEach(function (flash) {
    setTimeout(function () {
      flash.style.opacity = "0";
      flash.style.transform = "translateY(-4px)";
      setTimeout(function () { flash.remove(); }, 300);
    }, 5000);
  });

  window.addEventListener("resize", function () {
    if (window.innerWidth > 900) closeSidebar();
  });
});

async function syncOutlook() {
  const button = document.getElementById("sync-outlook");
  if (!button || button.dataset.running === "true") return;

  const original = button.innerHTML;
  button.dataset.running = "true";
  button.disabled = true;
  button.classList.add("is-loading");
  button.innerHTML = '<span class="spinner"></span><span class="sync-label">Syncing...</span>';

  showSyncToast("Outlook sync in progress · scanning PDL mailboxes and response evidence…", "info");

  try {
    const response = await fetch("/api/sync", {
      method: "POST",
      headers: {
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "application/json"
      },
      credentials: "same-origin"
    });

    const contentType = response.headers.get("content-type") || "";
    let payload;

    if (contentType.includes("application/json")) {
      payload = await response.json();
    } else {
      const text = await response.text();
      throw new Error("Server returned a non-JSON response (HTTP " + response.status + "). " + text.slice(0, 180));
    }

    if (!response.ok || !payload.ok) {
      throw new Error(payload.error || "Outlook synchronization failed.");
    }

    const result = payload.result || {};
    const sourceStatus = result.pdl_source_status || {};
    const matched = result.matched_by_pdl || {};
    const discovered = Object.keys(sourceStatus).filter(function (name) {
      const mode = (sourceStatus[name] || {}).mode || "";
      return mode === "shared_mailbox" || mode === "mounted_store";
    });

    let message = "Outlook synchronization completed successfully.";
    if (discovered.length) {
      const detail = discovered.slice(0, 3).map(function (name) {
        return name + " (" + (matched[name] || 0) + " matched)";
      }).join(", ");
      message += " Live PDL mailbox detected: " + detail + (discovered.length > 3 ? "…" : "");
    }
    showSyncToast(message, "success");

    setTimeout(function () {
      window.location.reload();
    }, 1800);

  } catch (error) {
    console.error("Outlook sync error:", error);
    showSyncToast(error.message || "Outlook synchronization failed.", "error");
    button.disabled = false;
    button.dataset.running = "false";
    button.classList.remove("is-loading");
    button.innerHTML = original;
  }
}

async function discoverOutlook() {
  const output = document.getElementById("stores");
  if (!output) return;

  output.textContent = "Discovering Outlook stores…";

  try {
    const response = await fetch("/api/discover-outlook", {
      headers: { "Accept": "application/json" },
      credentials: "same-origin"
    });

    const payload = await response.json();

    if (!response.ok || !payload.ok) {
      throw new Error(payload.error || "Unable to discover Outlook stores.");
    }

    output.textContent = JSON.stringify(payload.stores || [], null, 2);
  } catch (error) {
    console.error("Outlook discovery error:", error);
    output.textContent = "Error: " + (error.message || "Unable to discover Outlook stores.");
  }
}

function showSyncToast(message, type) {
  const container = document.getElementById("sync-status");
  if (!container) return;

  container.innerHTML = "";
  const toast = document.createElement("div");
  toast.className = "sync-toast " + (type || "info");
  toast.textContent = message;
  container.appendChild(toast);

  if (type !== "info") {
    setTimeout(function () {
      toast.style.opacity = "0";
      toast.style.transition = "opacity .25s ease";
      setTimeout(function () { toast.remove(); }, 250);
    }, 4500);
  }
}

/* Backward-compatible alias for pages that call this directly. */
window.syncOutlook = syncOutlook;
window.discoverOutlook = discoverOutlook;


function initTheme() {
  const saved = localStorage.getItem("pdl-theme") || "light";
  applyTheme(saved);

  const toggle = document.getElementById("theme-toggle");
  if (toggle) {
    toggle.addEventListener("click", function () {
      const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
      localStorage.setItem("pdl-theme", next);
      applyTheme(next);
    });
  }
}

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  const icon = document.getElementById("theme-icon");
  if (icon) icon.textContent = theme === "dark" ? "☀" : "☾";
}

function initIstClock(){const c=document.getElementById("ist-clock-value");if(!c)return;function r(){c.textContent=new Intl.DateTimeFormat("en-IN",{timeZone:"Asia/Kolkata",day:"2-digit",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false}).format(new Date())+" IST";}r();setInterval(r,1000);}

function initGlobalSearchShortcut(){
  const input=document.querySelector(".global-search-form input");
  if(!input)return;
  document.addEventListener("keydown",function(e){
    if((e.ctrlKey||e.metaKey) && e.key.toLowerCase()==="k"){
      e.preventDefault();
      input.focus();
      input.select();
    }
  });
}
initGlobalSearchShortcut();

/* Metrics-period selector: 24H / Week / Month / Custom. */
document.addEventListener("click", function (event) {
  const toggle = event.target.closest("[data-custom-range-toggle]");
  if (!toggle) return;
  const toolbar = toggle.closest("[data-metric-range]");
  if (!toolbar) return;
  const fields = toolbar.querySelector("[data-custom-range-fields]");
  if (!fields) return;
  fields.classList.add("open");
  fields.querySelectorAll("input, button").forEach(function (control) {
    control.disabled = false;
  });
  const firstDate = fields.querySelector('input[type="date"]');
  if (firstDate) firstDate.focus();
});
