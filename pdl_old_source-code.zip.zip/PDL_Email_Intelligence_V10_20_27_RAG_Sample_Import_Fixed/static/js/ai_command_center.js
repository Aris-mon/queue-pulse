(function(){
  "use strict";
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[c]));
  function set(id,v){const e=document.getElementById(id); if(e)e.textContent=v;}
  function renderSnapshot(s){
    const m=s.metrics_24h||{};
    set("cc-total",m.total||0); set("cc-response",m.response_required||0); set("cc-critical",m.critical||0); set("cc-high",m.high||0); set("cc-breached",m.tat_breached||0); set("cc-risk",m.tat_at_risk||0); set("cc-ai-pending",m.ai_pending||0); set("cc-ai-review",m.ai_review||0);
    const sync=document.getElementById("cc-last-sync"); if(sync)sync.textContent="Last sync: "+(s.last_sync?new Intl.DateTimeFormat("en-IN",{timeZone:"Asia/Kolkata",day:"2-digit",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:true}).format(new Date(s.last_sync))+" IST":"Never");
    const latest=document.getElementById("cc-latest-email");
    if(latest){ const e=s.latest_email; latest.innerHTML=e?`<a href="${esc(e.url)}"><strong>${esc(e.subject)}</strong><span>${esc(e.pdl||"Unmapped PDL")} · ${esc(e.received_at||"")}</span></a>`:'<div class="command-empty">No email data available.</div>'; }
  }
  async function loadAttention(){
    const box=document.getElementById("cc-attention-list"); if(!box)return;
    try{const r=await fetch("/api/v1/ai/attention",{cache:"no-store",credentials:"same-origin"}); if(!r.ok) throw new Error("HTTP "+r.status); const rows=await r.json();
      if(!Array.isArray(rows) || !rows.length){box.innerHTML='<div class="command-empty success">No critical/high AI attention items currently open.</div>';return;}
      box.innerHTML=rows.slice(0,10).map(x=>`<a class="command-attention-item sev-${esc((x.severity||"high").toLowerCase())}" href="/email/${x.email_id}"><div><span class="attention-tag">${esc((x.severity||"HIGH").toUpperCase())}</span><strong>${esc(x.title||x.subject||"Attention required")}</strong><p>${esc(x.message||x.recommended_action||"")}</p></div><span>›</span></a>`).join("");
    }catch(e){box.innerHTML='<div class="command-empty">Unable to load AI attention.</div>';}
  }
  async function loadBrief(){
    const box=document.getElementById("cc-brief"); if(!box)return;
    try{const r=await fetch("/api/v1/ai/daily-briefing?hours=24",{cache:"no-store",credentials:"same-origin"}); if(!r.ok) throw new Error("HTTP "+r.status); const x=await r.json();
      box.innerHTML=`<div class="brief-grid"><span>Emails</span><b>${x.emails_processed||0}</b><span>Response required</span><b>${x.response_required||0}</b><span>Critical / High</span><b>${x.critical_high||0}</b><span>SLA breaches</span><b>${x.sla_tat_breaches||0}</b></div>` + ((x.top_risks||[]).length?'<h4>Top risks</h4><ul>'+x.top_risks.slice(0,5).map(r=>`<li><a href="/email/${r.email_id}">${esc(r.pdl||"PDL")} — ${esc(r.subject||"Attention")}</a></li>`).join("")+'</ul>':'<p class="muted">No top risks detected.</p>');
    }catch(e){box.textContent="Unable to generate briefing.";}
  }
  async function loadHandover(){
    const box=document.getElementById("cc-handover"); if(!box)return;
    try{const r=await fetch("/api/v1/ai/shift-handover?hours=8",{cache:"no-store",credentials:"same-origin"}); if(!r.ok) throw new Error("HTTP "+r.status); const x=await r.json();
      box.innerHTML=`<div class="brief-grid"><span>Open items</span><b>${(x.open_items||[]).length}</b><span>Escalations</span><b>${(x.escalations||[]).length}</b><span>Overdue</span><b>${(x.overdue||[]).length}</b></div>` + ((x.open_items||[]).length?'<ul>'+x.open_items.slice(0,6).map(r=>`<li><a href="/email/${r.email_id}">${esc(r.pdl||"PDL")} — ${esc(r.subject||"Open item")}</a></li>`).join("")+'</ul>':'<p class="muted">No open customer actions in the selected handover window.</p>');
    }catch(e){box.textContent="Unable to load handover.";}
  }
  document.addEventListener("pdl:live",e=>renderSnapshot(e.detail));
  document.addEventListener("DOMContentLoaded",()=>{loadAttention();loadBrief();loadHandover(); document.getElementById("cc-refresh-brief")?.addEventListener("click",loadBrief);document.getElementById("cc-refresh-handover")?.addEventListener("click",loadHandover);setInterval(loadAttention,15000);});
})();
