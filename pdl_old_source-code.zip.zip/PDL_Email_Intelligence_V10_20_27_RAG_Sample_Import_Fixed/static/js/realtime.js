/* V9.6.1 near-real-time mailbox/UI monitor. */
(function () {
  "use strict";
  const POLL_MS = 15000;
  const ALERT_PREF = "pdl-desktop-alerts-enabled";
  let initialized = false;
  let lastAlertId = Number(localStorage.getItem("pdl-last-live-alert-id") || 0);
  let polling = false;

  function showToast(message, kind) {
    if (typeof window.showSyncToast === "function") window.showSyncToast(message, kind);
    else console.log(message);
  }
  function alertsWanted(){ return localStorage.getItem(ALERT_PREF) === "1"; }
  function setLive(online, label) {
    const pill = document.getElementById("live-monitor-pill"); if (!pill) return;
    pill.classList.toggle("offline", !online);
    const span = pill.querySelector("span"); if (span) span.textContent = label || (online ? "Live" : "Offline");
  }
  function updateBadge(count) {
    const badge = document.getElementById("notification-badge"); if (!badge) return;
    badge.hidden = !count; badge.textContent = count > 99 ? "99+" : String(count);
  }
  function istText(value) {
    if (!value) return "—";
    try { return new Intl.DateTimeFormat("en-IN", {timeZone:"Asia/Kolkata",day:"2-digit",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:true}).format(new Date(value)) + " IST"; }
    catch (_) { return value; }
  }
  async function fetchNotifications() {
    if (!alertsWanted() || !window.Notification || Notification.permission !== "granted") return;
    try {
      const response = await fetch("/api/v1/notifications?after_id=" + encodeURIComponent(lastAlertId), {credentials:"same-origin", cache:"no-store"});
      if (!response.ok) return;
      const data = await response.json();
      (data.items || []).forEach(function(alert) {
        lastAlertId = Math.max(lastAlertId, Number(alert.id || 0));
        localStorage.setItem("pdl-last-live-alert-id", String(lastAlertId));
        const n = new Notification(alert.title || "PDL Attention Required", {body: alert.message || "New operational notification",tag:"pdl-alert-"+alert.id,requireInteraction:String(alert.severity).toLowerCase()==="critical"});
        n.onclick = function () { window.focus(); window.location.href = alert.url || "/alerts"; };
      });
    } catch (_) {}
  }
  function updateNotificationState() {
    const button = document.getElementById("enable-browser-notifications");
    const state = document.getElementById("notification-state");
    const label = document.getElementById("notification-action-label");
    if (!button) return;
    button.hidden = false;
    if (!window.isSecureContext && location.hostname !== "localhost" && location.hostname !== "127.0.0.1") {
      button.disabled = true; if (label) label.textContent = "Alerts need HTTPS";
      button.title = "Browser desktop notifications require HTTPS (or localhost). In-app Notifications remain available.";
      if (state) state.hidden = true; return;
    }
    if (!window.Notification) {
      button.disabled = true; if(label) label.textContent="Alerts unavailable";
      button.title="This browser does not support desktop notifications."; if(state) state.hidden=true; return;
    }
    button.disabled = false;
    if (Notification.permission === "denied") {
      if(label) label.textContent="Alerts blocked"; button.title="Allow notifications for this site in browser settings.";
      if(state) state.hidden=true; return;
    }
    const enabled = Notification.permission === "granted" && alertsWanted();
    if(label) label.textContent = enabled ? "Disable alerts" : "Enable alerts";
    button.title = enabled ? "Disable desktop priority notifications" : "Enable desktop priority notifications";
    if(state){state.hidden=!enabled; state.textContent="🔔 Alerts on";}
  }
  async function poll() {
    if (polling) return; polling = true;
    try {
      const response = await fetch("/api/v1/live", {headers:{"Accept":"application/json"}, credentials:"same-origin", cache:"no-store"});
      if (!response.ok) throw new Error("HTTP " + response.status);
      const snapshot = await response.json(); setLive(true, snapshot.auto_sync_enabled ? "Live" : "Online");
      updateBadge(snapshot.unread_alerts || 0); await fetchNotifications();
      const m = snapshot.metrics_24h || {};
      [["live-total-24h",m.total],["live-response-24h",m.response_required],["live-critical-24h",m.critical],["live-high-24h",m.high],["live-breach-24h",m.tat_breached],["live-risk-24h",m.tat_at_risk],["live-ai-24h",m.ai_processing ?? 0]].forEach(function(pair){const el=document.getElementById(pair[0]);if(el)el.textContent=pair[1]??0;});
      const aiQueue=document.getElementById("live-ai-queued"); if(aiQueue) aiQueue.textContent = m.ai_queued ?? m.ai_pending ?? 0;
      const ls=document.getElementById("live-last-sync"); if(ls) ls.textContent="Last sync: "+(snapshot.last_sync?istText(snapshot.last_sync):"Never");
      document.dispatchEvent(new CustomEvent("pdl:live", {detail:snapshot}));
    } catch (_) { setLive(false,"Offline"); } finally { polling=false; }
  }
  function initNotifications() {
    const button=document.getElementById("enable-browser-notifications"); if(!button)return;
    updateNotificationState();
    button.addEventListener("click", async function(){
      if(!window.Notification || button.disabled) return;
      if(Notification.permission==="granted" && alertsWanted()){
        localStorage.setItem(ALERT_PREF,"0"); updateNotificationState(); showToast("Desktop PDL alerts disabled. In-app notifications remain available.","success"); return;
      }
      if(Notification.permission==="denied"){showToast("Browser notifications are blocked. Allow them in browser site settings.","error");return;}
      try{
        const result=await Notification.requestPermission();
        if(result==="granted"){
          localStorage.setItem(ALERT_PREF,"1");
          const response=await fetch("/api/v1/notifications?after_id=0",{credentials:"same-origin",cache:"no-store"});
          if(response.ok){const data=await response.json();const items=data.items||[];if(items.length){lastAlertId=Math.max.apply(null,items.map(x=>Number(x.id||0)));localStorage.setItem("pdl-last-live-alert-id",String(lastAlertId));}}
          showToast("Desktop PDL alerts enabled.","success");
        }
        updateNotificationState();
      }catch(_){showToast("Unable to enable desktop notifications in this browser.","error");}
    });
  }
  document.addEventListener("DOMContentLoaded",function(){if(initialized)return;initialized=true;initNotifications();poll();setInterval(poll,POLL_MS);});
})();
