from types import SimpleNamespace

from ai.context import _operational_signals
from ai.rules import classify


def email(subject, body):
    return SimpleNamespace(
        subject=subject, body=body, sender_type="customer",
        email_category="general", severity="critical", escalation_level="critical",
        response_required=True, responded=False, monitoring_excluded=False,
        tat_breached=False, received_at=None, tat_minutes=240,
        pdl_name="PDL", pdl_id=1, customer_name="Customer", sender_domain="example.com",
        ai_summary=None, recommended_action=None,
    )


def test_planned_downtime_is_not_active_outage():
    signals = _operational_signals(
        "Issue outage",
        "Please confirm if downtime is required for disk upgradation. Please schedule at 2 PM on 19th Aug.",
    )
    assert signals["planned_maintenance"] is True
    assert signals["actual_outage"] is False


def test_rules_do_not_use_stale_critical_severity_for_planned_maintenance():
    row = email(
        "Issue outage",
        "Please confirm if downtime is required for disk upgradation. Please schedule at 2 PM on 19th Aug.",
    )
    result = classify(row, context={"signals": _operational_signals(row.subject, row.body)})
    assert result["priority"] == "HIGH"
    assert result["sentiment"] in {"CONCERNED", "NEUTRAL"}


def test_active_outage_is_critical_and_not_neutral():
    signals = _operational_signals("Production issue", "Production is down and customers are unable to proceed.")
    assert signals["actual_outage"] is True
    assert signals["customer_blocked"] is True
