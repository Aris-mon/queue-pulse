from types import SimpleNamespace

from intelligence import _latest_message_text, strip_signature
from ai.engine import _merge


def test_signature_escalation_contact_is_not_classified_as_operational_text():
    text = "Please confirm tomorrow's schedule.\nRegards\nJohn Smith\nFor any escalations, please contact the delivery manager."
    cleaned = _latest_message_text(text)
    assert "escalation" not in cleaned.lower()
    assert "delivery manager" not in cleaned.lower()


def test_inline_signature_escalation_contact_is_removed():
    text = "Please confirm the schedule. Thanks, John | For escalations please contact the manager."
    cleaned = strip_signature(text)
    assert "escalation" not in cleaned.lower()


def test_qwen_information_request_intent_updates_live_category():
    email = SimpleNamespace(
        sender_type="customer",
        subject="Question",
        body="Could you confirm the maintenance window?",
        responded=False,
    )
    rules = {
        "intent": "GENERAL",
        "category": "general",
        "sentiment": "NEUTRAL",
        "priority": "NORMAL",
        "response_required": True,
        "escalation_level": "LOW",
        "escalation": False,
        "confidence": 0.9,
        "recognition": False,
    }
    ai = {
        "intent": "INFORMATION_REQUEST",
        "sentiment": "NEUTRAL",
        "priority": "NORMAL",
        "response_required": True,
        "recognition": False,
        "escalation": False,
        "summary": "Customer asks for confirmation.",
        "confidence": 0.95,
    }
    merged = _merge(rules, ai, email, context={"signals": {}})
    assert merged["category"] == "information_request"
