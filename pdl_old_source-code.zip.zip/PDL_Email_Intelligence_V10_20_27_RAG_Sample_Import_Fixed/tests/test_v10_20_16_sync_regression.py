from pathlib import Path


def test_intel_is_initialized_before_first_runtime_use():
    source = (
        Path(__file__).resolve().parents[1] / "outlook_connector.py"
    ).read_text(encoding="utf-8")

    build_pos = source.index("intel = build_intelligence(")
    first_runtime_use = source.index("intel.get(")

    assert build_pos < first_runtime_use


def test_sync_errors_do_not_persist_message_content():
    source = (
        Path(__file__).resolve().parents[1] / "outlook_connector.py"
    ).read_text(encoding="utf-8")

    assert "safe_get(message, 'Subject', '')" not in source[source.index("errors.append("):source.index("set_sync_state(\"sync_progress\", f\"Committing")]
    assert 'f"{folder_path}:"' not in source


def test_recognition_is_excluded_from_tat_breach_calculation():
    source = (
        Path(__file__).resolve().parents[1] / "outlook_connector.py"
    ).read_text(encoding="utf-8")

    tat_block = source[source.index("tat_breached = bool("):source.index("# Rebuild only when TAT changes")]
    assert 'email_category' in tat_block
    assert '"recognition"' in tat_block
