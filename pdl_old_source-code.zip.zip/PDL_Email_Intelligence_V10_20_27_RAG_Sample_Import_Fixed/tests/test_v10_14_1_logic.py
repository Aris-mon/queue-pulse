from datetime import datetime, timezone
from types import SimpleNamespace

from local_ai_agent import analyze_email
from intelligence import detect_email_category, detect_response_requirement


def test_schedule_request_is_not_recognition():
    assert detect_email_category("Schedule installation", "Please schedule the installation for tomorrow. Thank you.") == "schedule_request"


def test_courtesy_is_not_recognition():
    r = analyze_email("", "Thank you for the update.")
    assert r.recognition is False
    assert r.sentiment == "neutral"


def test_substantive_praise_is_recognition():
    r = analyze_email("", "Thank you for the excellent support during the installation. Your engineer did an outstanding job.")
    assert r.recognition is True
    assert r.sentiment == "positive"


def test_successful_resolution_is_not_automatically_positive():
    r = analyze_email("", "The issue has been resolved and the service is back to normal.")
    assert r.sentiment in {"neutral", "concerned"}


def test_engineer_message_never_response_required():
    email = SimpleNamespace(sender_type="engineer")
    ok, reason = detect_response_requirement("Urgent: please confirm schedule", "Please confirm the required schedule today.", sender_type="engineer")
    assert ok is False


def test_customer_schedule_is_response_required():
    ok, reason = detect_response_requirement("Schedule request", "Please confirm availability for tomorrow.", sender_type="customer")
    assert ok is True
