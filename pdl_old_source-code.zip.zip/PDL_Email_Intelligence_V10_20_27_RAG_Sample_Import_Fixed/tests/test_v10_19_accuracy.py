from types import SimpleNamespace

from local_ai_agent import analyze_email
from intelligence import build_intelligence
from ai.rules import classify


def email(subject, body, sender_type="customer"):
    return SimpleNamespace(
        subject=subject, body=body, sender_type=sender_type,
        email_category="general", severity="normal", escalation_level="low",
        response_required=True, responded=False, monitoring_excluded=False,
        tat_breached=False, received_at=None, tat_minutes=240,
        pdl_name="PDL", pdl_id=1, customer_name="Customer", sender_domain="example.com",
        ai_summary=None, recommended_action=None,
    )


def test_signature_escalation_is_ignored():
    a = analyze_email("Schedule confirmation", "Please confirm tomorrow's schedule.\nRegards\nJohn\nFor any escalations, please contact the support manager.")
    assert a.escalation_risk is False


def test_actual_outage_is_critical_and_concerned():
    r = build_intelligence("Issue", "Production is down and the service is unavailable for customers.", "customer@example.com", "customer")
    assert r["severity"] == "critical"
    assert r["sentiment"] == "concerned"


def test_downtime_question_is_schedule_and_not_recognition():
    r = build_intelligence("Schedule", "Please confirm any downtime is required for disk upgradation. Please schedule at 2 PM on 19th Aug.", "customer@example.com", "customer")
    assert r["email_category"] == "schedule_request"
    assert r["response_required"] is True
    assert r["email_category"] != "recognition"


def test_rules_no_longer_emit_waiting_internal_for_customer():
    e = email("Please confirm", "Please confirm the schedule.")
    result = classify(e)
    assert result["thread_status"] == "AWAITING_RESPONSE"
