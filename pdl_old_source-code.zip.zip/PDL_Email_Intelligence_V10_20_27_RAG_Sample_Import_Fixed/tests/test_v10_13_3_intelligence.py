from intelligence import build_intelligence


def test_courtesy_is_not_recognition_or_critical():
    r = build_intelligence("Thank you", "Thank you.", "customer@example.com", "customer")
    assert r["email_category"] != "recognition"
    assert r["severity"] in {"normal", "medium"}
    assert r["response_required"] is False


def test_substantive_customer_recognition_is_recognition():
    r = build_intelligence(
        "Excellent installation support",
        "Thank you for the excellent support during the installation. The work was completed successfully and your engineer did an outstanding job.",
        "customer@example.com", "customer"
    )
    assert r["email_category"] == "recognition"
    assert r["response_required"] is False
    assert r["severity"] == "normal"


def test_internal_team_member_missed_call_can_be_critical():
    r = build_intelligence(
        "Customer call missed",
        "Engineer did not join the customer call. The deployment is blocked.",
        "engineer@hpe.com", "engineer"
    )
    assert r["severity"] == "critical"
    assert r["monitoring_excluded"] is True


def test_quoted_history_does_not_trigger_escalation():
    r = build_intelligence(
        "Thanks for the update",
        "Thanks for the update.\n\nOn Monday someone wrote:\nPlease escalate this to management.",
        "customer@example.com", "customer"
    )
    assert r["email_category"] != "escalation"
    assert r["escalation_level"] == "low"


def test_configured_engineer_never_becomes_response_required_from_action_words():
    from intelligence import detect_response_requirement
    required, reason = detect_response_requirement(
        "Please confirm customer schedule",
        "Please confirm the schedule and provide the required details. This is urgent.",
        sender_type="engineer",
        sentiment="concerned",
    )
    assert required is False
    assert "Configured engineer" in (reason or "")


def test_internal_customer_impact_event_can_still_be_analyzed_separately():
    from intelligence import detect_response_requirement
    required, _ = detect_response_requirement(
        "Engineer missed customer call",
        "Engineer did not join the customer call and the deployment is blocked.",
        sender_type="engineer",
        sentiment="concerned",
    )
    assert required is False


def test_engineer_action_words_cannot_create_customer_workload_or_ordinary_alert_signal():
    from intelligence import build_intelligence
    r = build_intelligence(
        "Urgent: please confirm schedule",
        "Please confirm the required schedule and send an update ASAP.",
        "engineer@hpe.com", "engineer"
    )
    assert r["response_required"] is False
    assert r["monitoring_excluded"] is True


def test_engineer_critical_operational_event_remains_critical():
    from intelligence import build_intelligence
    r = build_intelligence(
        "Customer call missed",
        "Engineer did not join the customer call. The deployment is blocked.",
        "engineer@hpe.com", "engineer"
    )
    assert r["response_required"] is False
    assert r["monitoring_excluded"] is True
    assert r["severity"] == "critical"
