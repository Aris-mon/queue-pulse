"""Offline-safe preflight for PDL Local RAG / LangGraph.

This script does not read email contents and does not download any model.
Run from the project root with the application's virtual-environment Python.
"""
from __future__ import annotations

import importlib
import json
import os
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def check_import(name: str) -> tuple[bool, str]:
    try:
        module = importlib.import_module(name)
        version = getattr(module, "__version__", None) or "installed"
        return True, str(version)
    except Exception as exc:
        return False, str(exc)


def main() -> int:
    required = [
        "flask", "flask_login", "flask_sqlalchemy", "sqlalchemy", "apscheduler",
        "requests", "cryptography", "langgraph", "chromadb", "sentence_transformers",
    ]
    failures: list[str] = []
    print("=== Python dependencies ===")
    for name in required:
        ok, detail = check_import(name)
        print(f"{name:24} {'OK' if ok else 'FAIL'}  {detail}")
        if not ok:
            failures.append(f"dependency:{name}")

    model_path = ROOT / os.getenv("AI_EMBEDDING_MODEL_PATH", "models/all-MiniLM-L6-v2")
    if not model_path.is_absolute():
        model_path = ROOT / model_path
    print("\n=== Embedding model ===")
    print(f"path: {model_path}")
    model_ok = model_path.exists() and (model_path / "modules.json").exists()
    print(f"staged: {'YES' if model_ok else 'NO'}")
    if not model_ok:
        failures.append("embedding-model")

    print("\n=== ChromaDB ===")
    try:
        import chromadb
        from chromadb.config import Settings
        rag_path = Path(os.getenv("AI_RAG_PATH", "instance/chroma"))
        if not rag_path.is_absolute():
            rag_path = ROOT / rag_path
        rag_path.mkdir(parents=True, exist_ok=True)
        client = chromadb.PersistentClient(path=str(rag_path), settings=Settings(anonymized_telemetry=False))
        collection = client.get_or_create_collection(
            name="pdl_validated_training",
            metadata={"hnsw:space": "cosine", "security": "local_only"},
        )
        print(f"path: {rag_path}")
        print(f"collection: pdl_validated_training")
        print(f"indexed examples: {collection.count()}")
    except Exception as exc:
        print(f"FAIL: {exc}")
        failures.append("chromadb")

    print("\n=== Ollama ===")
    base_url = os.getenv("AI_BASE_URL", "http://127.0.0.1:11434").rstrip("/")
    model = os.getenv("AI_MODEL", "qwen3:8b")
    try:
        with urllib.request.urlopen(base_url + "/api/tags", timeout=3) as response:
            data = json.loads(response.read().decode("utf-8"))
        names = [str(x.get("name") or "") for x in data.get("models", [])]
        present = any(n == model or n.split(":")[0] == model.split(":")[0] for n in names)
        print(f"endpoint: {base_url} OK")
        print(f"configured model: {model} {'FOUND' if present else 'NOT FOUND'}")
        if not present:
            failures.append("ollama-model")
    except Exception as exc:
        print(f"endpoint: {base_url} FAIL ({exc})")
        failures.append("ollama")

    print("\n=== Result ===")
    if failures:
        print("Preflight has unresolved items: " + ", ".join(failures))
        print("The application still fails safe to deterministic rules when local AI/RAG is unavailable.")
        return 2
    print("Local AI/RAG prerequisites are ready.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
