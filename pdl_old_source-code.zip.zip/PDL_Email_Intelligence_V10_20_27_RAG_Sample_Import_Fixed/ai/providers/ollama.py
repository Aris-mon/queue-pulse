from __future__ import annotations
import json
import os
import re
import time
import urllib.request
from urllib.parse import urlparse
from typing import Any
from .base import AIProvider, ProviderResponse
from ..configuration import get_ai_setting

# Keep the model output intentionally small.  A large 30+ field JSON schema
# causes unnecessary generation time and makes local 8B models more likely to
# hit token/structured-output limits.  The application fills operational facts
# from deterministic rules/database state.
EMAIL_ANALYSIS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "intent": {
            "type": "string",
            "enum": [
                "SCHEDULE_REQUEST", "SCHEDULE_CONFIRMATION", "SCHEDULE_CHANGE",
                "SCHEDULE_CANCELLATION", "STATUS_REQUEST", "FOLLOW_UP",
                "TECHNICAL_SUPPORT", "INFORMATION_REQUEST", "ESCALATION",
                "INFORMATION_ONLY", "GENERAL", "RECOGNITION"
            ],
        },
        "sentiment": {"type": "string", "enum": ["NEUTRAL", "CONCERNED", "NEGATIVE", "POSITIVE"]},
        "priority": {"type": "string", "enum": ["LOW", "NORMAL", "HIGH", "CRITICAL"]},
        "response_required": {"type": "boolean"},
        "recognition": {"type": "boolean"},
        "escalation": {"type": "boolean"},
        "summary": {"type": "string", "maxLength": 300},
        "confidence": {"type": "number", "minimum": 0, "maximum": 1}
    },
    "required": [
        "intent", "sentiment", "priority", "response_required",
        "recognition", "escalation", "summary", "confidence"
    ]
}


class OllamaProvider(AIProvider):
    name = "ollama"

    def __init__(self, base_url: str, model: str, timeout: int = 240,
                 temperature: float = 0.0, think: str | bool = False,
                 keep_alive: str = "30m"):
        self.base_url = (base_url or "http://127.0.0.1:11434").rstrip("/")
        self.model = model
        self.timeout = timeout
        self.temperature = temperature
        self.think = self._parse_think(think)
        self.keep_alive = keep_alive or "10m"

    @staticmethod
    def _parse_think(value: str | bool) -> bool | str:
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in {"true", "1", "yes", "on"}:
            return True
        if text in {"false", "0", "no", "off", ""}:
            return False
        if text in {"low", "medium", "high"}:
            return text
        return False

    def _assert_endpoint_policy(self):
        local_only = str(get_ai_setting("AI_LOCAL_ONLY") or "true").strip().lower() not in {"0", "false", "no", "off"}
        if not local_only:
            return
        host = (urlparse(self.base_url).hostname or "").lower()
        if host not in {"127.0.0.1", "localhost", "::1"}:
            raise RuntimeError(
                f"AI_LOCAL_ONLY is enabled; remote Ollama endpoint is blocked: {self.base_url}"
            )

    def _request(self, path: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        self._assert_endpoint_policy()
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        request = urllib.request.Request(
            f"{self.base_url}{path}", data=data,
            headers={"Content-Type": "application/json"},
            method="GET" if payload is None else "POST",
        )
        with urllib.request.urlopen(request, timeout=self.timeout) as response:
            return json.loads(response.read().decode("utf-8"))

    def health(self) -> dict[str, Any]:
        started = time.perf_counter()
        try:
            response = self._request("/api/tags")
            names = [m.get("name", "") for m in response.get("models", [])]
            found = any(name == self.model or name.split(":")[0] == self.model.split(":")[0] for name in names)
            return {
                "connected": True,
                "model": self.model,
                "model_available": found,
                "latency_ms": int((time.perf_counter() - started) * 1000),
                "error": None if found else f"Model {self.model} is not installed in Ollama",
            }
        except Exception as exc:
            return {
                "connected": False,
                "model": self.model,
                "model_available": False,
                "latency_ms": int((time.perf_counter() - started) * 1000),
                "error": str(exc),
            }

    def generate_json(self, system_prompt: str, user_prompt: str) -> ProviderResponse:
        started = time.perf_counter()
        # Ollama supports passing the actual JSON Schema in `format`; this is
        # materially stronger than asking for generic JSON and reduces malformed
        # classifier responses. See Ollama structured-output documentation.
        payload = {
            "model": self.model,
            "stream": False,
            "format": EMAIL_ANALYSIS_SCHEMA,
            "options": {
                "temperature": self.temperature,
                "num_predict": max(192, min(int(get_ai_setting("AI_MAX_TOKENS") or "256"), 512)),
                "num_ctx": max(4096, min(int(get_ai_setting("AI_NUM_CTX") or "8192"), 16384)),
            },
            "keep_alive": self.keep_alive,
            "think": self.think,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        }
        try:
            result = self._request("/api/chat", payload)
        except Exception as first_exc:
            # Some older Ollama builds reject the `think` option even though
            # /api/tags works. Retry once with the option omitted; do not retry
            # arbitrary failures repeatedly.
            message_text = str(first_exc).lower()
            if "think" in message_text or "unknown field" in message_text or "invalid option" in message_text:
                payload.pop("think", None)
                result = self._request("/api/chat", payload)
            else:
                raise
        message = result.get("message") or {}
        content = message.get("content", "") or ""
        # Schema-constrained output should normally be valid. If a provider
        # still returns malformed JSON, perform one bounded retry with a compact
        # repair instruction. LangGraph also validates the final response.
        candidate_text = content.strip() if content else ""
        if candidate_text.startswith("```"):
            candidate_text = re.sub(r"^```(?:json)?\s*", "", candidate_text, flags=re.I)
            candidate_text = re.sub(r"\s*```$", "", candidate_text).strip()
        retry_needed = False
        if candidate_text:
            try:
                json.loads(candidate_text)
            except Exception:
                retry_needed = True
        if retry_needed:
            retry_payload = dict(payload)
            retry_payload["messages"] = list(payload["messages"]) + [{
                "role": "user",
                "content": "Return only one valid JSON object conforming exactly to the supplied schema. No markdown, commentary, or extra text.",
            }]
            retry_options = dict(payload.get("options") or {})
            retry_options["num_predict"] = max(int(retry_options.get("num_predict", 256)), 384)
            retry_payload["options"] = retry_options
            retry_result = self._request("/api/chat", retry_payload)
            retry_message = retry_result.get("message") or {}
            retry_content = retry_message.get("content", "") or ""
            if retry_content:
                result = retry_result
                message = retry_message
                content = retry_content
        if not content and message.get("thinking"):
            # Keep the failure explicit; reasoning text is not a valid classifier
            # result and must never be parsed as the final JSON.
            raise ValueError("Ollama returned thinking content but no structured message content; set AI_THINK=false for classification")
        return ProviderResponse(
            content=content,
            model=result.get("model") or self.model,
            latency_ms=int((time.perf_counter() - started) * 1000),
            raw=result,
        )
