from __future__ import annotations
from .base import AIProvider


class DisabledProvider(AIProvider):
    name = "rules"
    def health(self):
        return {"connected": False, "model": "rules-only", "model_available": False,
                "latency_ms": 0, "error": "AI provider disabled; deterministic fallback active"}
    def generate_json(self, system_prompt, user_prompt):
        raise RuntimeError("AI provider disabled")
