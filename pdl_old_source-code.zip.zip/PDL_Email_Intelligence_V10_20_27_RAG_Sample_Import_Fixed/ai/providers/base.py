from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass(slots=True)
class ProviderResponse:
    content: str
    model: str
    latency_ms: int
    raw: dict[str, Any] | None = None


class AIProvider(ABC):
    name = "base"

    @abstractmethod
    def health(self) -> dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    def generate_json(self, system_prompt: str, user_prompt: str) -> ProviderResponse:
        raise NotImplementedError
