from __future__ import annotations
from datetime import datetime, timedelta, timezone
from sqlalchemy import or_
from db import Email, AIAnalysis


def _latest_analysis(email_id: int):
    return AIAnalysis.query.filter_by(email_id=email_id, status="COMPLETE").order_by(AIAnalysis.created_at.desc()).first()


def attention_items(query, limit=50):
    rows = query.order_by(Email.received_at.desc()).limit(limit).all()
    items=[]
    for email in rows:
        analysis=_latest_analysis(email.id)
        result=analysis.result if analysis else {}
        priority=(result.get("priority") or (email.severity or "normal")).upper()
        if priority in {"CRITICAL","HIGH"} or email.tat_breached or email.escalation_level in {"high","critical"}:
            items.append({"email_id":email.id,"pdl":email.pdl_name,"customer":email.customer_name,
                          "subject":email.subject,"priority":priority,"tat_breached":email.tat_breached,
                          "risk":result.get("customer_risk") or (email.escalation_level or "low").upper(),
                          "recommended_action":result.get("recommended_action") or email.recommended_action})
    return items


def daily_briefing(query, since_hours=24):
    since=datetime.now(timezone.utc)-timedelta(hours=since_hours)
    q=query.filter(Email.received_at>=since)
    total=q.count(); response=q.filter(Email.response_required.is_(True), Email.responded.is_(False), Email.monitoring_excluded.is_(False)).count()
    breached=q.filter(Email.tat_breached.is_(True)).count()
    high=q.filter(or_(Email.severity.in_(["high","critical"]), Email.escalation_level.in_(["high","critical"]))).count()
    risks=attention_items(q, 10)[:5]
    return {"period_hours":since_hours,"emails_processed":total,"response_required":response,
            "critical_high":high,"sla_tat_breaches":breached,"top_risks":risks,
            "generated_at":datetime.now(timezone.utc).isoformat()}


def shift_handover(query, hours=8):
    since=datetime.now(timezone.utc)-timedelta(hours=hours)
    q=query.filter(Email.received_at>=since)
    open_rows=q.filter(Email.response_required.is_(True),Email.responded.is_(False),Email.monitoring_excluded.is_(False)).order_by(Email.received_at.desc()).limit(100).all()
    return {"period_hours":hours,
            "open_items":[{"email_id":e.id,"pdl":e.pdl_name,"customer":e.customer_name,"subject":e.subject,"received_at":e.received_at.isoformat()} for e in open_rows],
            "escalations":attention_items(q,50),
            "overdue":[{"email_id":e.id,"subject":e.subject,"pdl":e.pdl_name} for e in q.filter(Email.tat_breached.is_(True)).limit(50).all()],
            "generated_at":datetime.now(timezone.utc).isoformat()}


def suggested_reply(email: Email):
    """Draft only; deliberately avoids inventing dates, engineers or commitments."""
    analysis=_latest_analysis(email.id); result=analysis.result if analysis else {}
    if result.get("response_required") is False:
        return {"draft":"","reason":"The current intelligence result does not indicate that a response is required."}
    customer=email.sender_name or "Customer"
    draft=(f"Hello {customer},\n\nThank you for your email. We have noted your request and are reviewing it with the relevant team. "
           "We will provide an update once the required information is confirmed.\n\nRegards,")
    return {"draft":draft,"reason":"Conservative acknowledgement based only on available email context; no date, engineer or commitment was invented."}
