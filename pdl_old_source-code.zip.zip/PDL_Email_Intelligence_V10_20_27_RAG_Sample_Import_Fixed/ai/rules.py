from __future__ import annotations
import re
from datetime import datetime, timedelta, timezone
from local_ai_agent import analyze_email
from intelligence import detect_email_category

INTENTS = {
    "SCHEDULE_REQUEST": ("schedule", "availability", "book", "slot"),
    "SCHEDULE_CONFIRMATION": ("confirmed", "confirmation", "works for us"),
    "SCHEDULE_CHANGE": ("reschedule", "change the schedule", "new date", "postpone"),
    "SCHEDULE_CANCELLATION": ("cancel", "cancellation"),
    "STATUS_REQUEST": ("status", "update", "progress", "any news"),
    "ACCESS_REQUEST": ("access", "credentials", "permission"),
    "CUSTOMER_ESCALATION": ("escalate", "escalation", "management", "complaint"),
    "PRODUCTION_IMPACT": ("production down", "production impact", "outage", "service down"),
    "BLOCKER": ("blocked", "blocker", "blocking"),
    "APPROVAL_REQUIRED": ("approve", "approval"),
    "FOLLOW_UP": ("follow up", "following up", "still waiting", "reminder"),
    "INFORMATION_ONLY": ("for your information", "fyi"),
}


def _detect_intent(text: str) -> str:
    low = text.lower()
    if any(p in low for p in ("is downtime required", "will there be downtime", "downtime required", "maintenance window")):
        return "SCHEDULE_CONFIRMATION"
    best = (0, "OTHER")
    for intent, phrases in INTENTS.items():
        score = sum(1 for p in phrases if p in low)
        if score > best[0]: best = (score, intent)
    return best[1]


def _deadline(text: str, received_at: datetime | None):
    base = received_at or datetime.now(timezone.utc)
    low = text.lower()
    source = None
    dt = None
    if "tomorrow" in low:
        dt, source = base + timedelta(days=1), "tomorrow"
    elif re.search(r"\btoday\b|\beod\b|\bcob\b", low):
        dt, source = base, "today/EOD/COB"
    return dt, source


def classify(email, pdl_candidates: list[dict] | None = None, context: dict | None = None) -> dict:
    subject, body = email.subject or "", email.body or ""
    text = f"{subject}\n{body}"
    agent = analyze_email(subject, body)
    intent = _detect_intent(text)
    # Never trust a previously stored category during re-analysis. The newest
    # authored message is the source of truth; otherwise an old Recognition
    # label can survive after the thread changes to a schedule request.
    category = detect_email_category(subject, body, agent=agent).upper()
    # Customer recognition is a strict operational category. Internal
    # appreciation must never enter the customer-recognition metric.
    if agent.recognition and email.sender_type == "customer":
        category = "RECOGNITION"
    elif email.sender_type != "customer" and category == "RECOGNITION":
        category = "GENERAL"
    # Never use a stale Email.severity as the primary source during re-analysis.
    # Derive priority from the newest authored content/context, then let Qwen
    # enrich ambiguous cases.
    signals = (context or {}).get("signals", {})
    if signals.get("actual_outage"):
        priority = "CRITICAL"
    elif signals.get("customer_meeting_miss") and (signals.get("customer_blocked") or signals.get("explicit_escalation")):
        priority = "CRITICAL"
    elif signals.get("customer_blocked") or signals.get("explicit_escalation") or signals.get("urgent"):
        priority = "HIGH"
    elif signals.get("planned_maintenance"):
        priority = "HIGH" if signals.get("action_request") else "NORMAL"
    else:
        priority = "NORMAL"
    if priority not in {"CRITICAL", "HIGH", "NORMAL", "LOW"}: priority = "NORMAL"
    # Recognition/courtesy is not an operational criticality. If an old/stale
    # severity value says CRITICAL but the newest message is a pure appreciation
    # with no response/action/risk, reset it before it reaches notifications.
    if agent.recognition and email.sender_type == "customer":
        priority = "NORMAL"
    response_state = "RESPONSE_REQUIRED" if email.response_required and not email.responded and not email.monitoring_excluded else "NO_RESPONSE_REQUIRED"
    deadline_dt, deadline_source = _deadline(text, email.received_at)
    if signals.get("actual_outage"):
        risk = "CRITICAL"
    elif signals.get("customer_blocked") or signals.get("explicit_escalation"):
        risk = "HIGH"
    elif signals.get("planned_maintenance"):
        risk = "MEDIUM"
    else:
        risk = "LOW"
    frustration = "HIGH" if agent.sentiment == "negative" else "MEDIUM" if agent.sentiment == "concerned" else "LOW"
    confidence = min(0.98, max(0.50, agent.confidence / 100.0))
    return {
        "pdl": email.pdl_name or "UNKNOWN", "pdl_id": email.pdl_id,
        "customer": email.customer_name or (email.sender_domain or ""),
        "intent": intent, "category": category,
        "sentiment": agent.sentiment.upper(), "customer_frustration": frustration,
        "customer_confidence": "LOW" if frustration == "HIGH" else "MEDIUM" if frustration == "MEDIUM" else "HIGH",
        "escalation_risk": risk, "relationship_risk": risk,
        "priority": priority, "response_requirement": response_state,
        "response_required": response_state in {"RESPONSE_REQUIRED", "ACTION_REQUIRED"},
        "deadline_datetime": deadline_dt.isoformat() if deadline_dt else None,
        "deadline_timezone": "source/unknown", "deadline_source_text": deadline_source,
        "deadline_confidence": 0.70 if deadline_dt else 0.0,
        "schedule_date": None, "schedule_time": None, "escalation_level": ("critical" if signals.get("actual_outage") else "high" if signals.get("customer_blocked") or signals.get("explicit_escalation") else "medium" if signals.get("planned_maintenance") else "low").upper(),
        "customer_risk": risk, "business_impact": "Active outage/customer impact detected" if signals.get("actual_outage") else ("Customer/operational risk detected" if risk in {"HIGH", "CRITICAL"} else "No high-impact signal detected"),
        "escalation": bool(signals.get("actual_outage") or signals.get("explicit_escalation")) or priority == "CRITICAL",
        "required_action": "Respond/review" if response_state == "RESPONSE_REQUIRED" else "Monitor",
        "recommended_action": email.recommended_action or "Review the email and thread context.",
        "summary": email.ai_summary or f"{intent.replace('_',' ').title()} classified by deterministic rules.",
        "thread_status": (
            "RESPONDED" if email.responded else
            "TAT_BREACHED" if email.tat_breached and response_state == "RESPONSE_REQUIRED" else
            "AWAITING_RESPONSE" if response_state == "RESPONSE_REQUIRED" else
            "ESCALATED" if email.escalation_level in {"high", "critical"} else
            "INFORMATIONAL"
        ),
        "confidence": confidence, "human_review_required": confidence < 0.72,
        "reasoning": list(agent.reasons), "source": "rules",
    }
