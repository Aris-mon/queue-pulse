from __future__ import annotations

import json
from typing import Any, TypedDict

REQUIRED_KEYS = {
    "intent", "sentiment", "priority", "response_required",
    "recognition", "escalation", "summary", "confidence",
}


class EmailAIState(TypedDict, total=False):
    system_prompt: str
    user_prompt: str
    provider: Any
    rag_section: str
    response_content: str
    candidate: dict[str, Any]
    attempts: int
    max_attempts: int
    error: str | None


def _validate(content: str) -> dict[str, Any]:
    text = (content or "").strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1] if "\n" in text else text
        if text.endswith("```"):
            text = text[:-3].strip()
    obj = json.loads(text)
    if not isinstance(obj, dict):
        raise ValueError("AI response is not a JSON object")
    missing = REQUIRED_KEYS - set(obj)
    if missing:
        raise ValueError("AI response missing fields: " + ", ".join(sorted(missing)))
    allowed = REQUIRED_KEYS
    extra = set(obj) - allowed
    if extra:
        raise ValueError("AI response contains unsupported fields: " + ", ".join(sorted(extra)))
    if str(obj.get("intent", "")).upper() not in {
        "SCHEDULE_REQUEST", "SCHEDULE_CONFIRMATION", "SCHEDULE_CHANGE",
        "SCHEDULE_CANCELLATION", "STATUS_REQUEST", "FOLLOW_UP",
        "TECHNICAL_SUPPORT", "INFORMATION_REQUEST", "ESCALATION",
        "INFORMATION_ONLY", "GENERAL", "RECOGNITION",
    }:
        raise ValueError("AI response has invalid intent")
    if str(obj.get("sentiment", "")).upper() not in {"NEUTRAL", "CONCERNED", "NEGATIVE", "POSITIVE"}:
        raise ValueError("AI response has invalid sentiment")
    if str(obj.get("priority", "")).upper() not in {"LOW", "NORMAL", "HIGH", "CRITICAL"}:
        raise ValueError("AI response has invalid priority")
    for key in ("response_required", "recognition", "escalation"):
        if not isinstance(obj.get(key), bool):
            raise ValueError(f"AI response field {key} must be boolean")
    try:
        confidence = float(obj.get("confidence"))
    except (TypeError, ValueError):
        raise ValueError("AI response confidence must be numeric")
    if not 0 <= confidence <= 1:
        raise ValueError("AI response confidence must be between 0 and 1")
    if len(str(obj.get("summary") or "")) > 300:
        raise ValueError("AI response summary is too long")
    return obj


def _fallback_linear(state: EmailAIState) -> EmailAIState:
    last_error = None
    prompt = state["user_prompt"]
    for attempt in range(1, 3):
        try:
            response = state["provider"].generate_json(
                state["system_prompt"] + state.get("rag_section", ""),
                prompt,
            )
            candidate = _validate(response.content)
            return {**state, "response_content": response.content, "candidate": candidate,
                    "attempts": attempt, "error": None}
        except Exception as exc:
            last_error = str(exc)
            prompt = prompt + "\n\nREPAIR: Return only one valid JSON object matching the required schema. No markdown."
    return {**state, "attempts": 2, "error": last_error or "AI validation failed"}


def run_email_ai_graph(*, system_prompt: str, user_prompt: str, provider: Any,
                       rag_section: str = "", max_attempts: int = 2) -> dict[str, Any]:
    """Run the local classifier through a small, deterministic LangGraph.

    LangGraph is used only as orchestration. Outlook, SQLAlchemy, PDL authority,
    TAT and notification logic remain outside the graph.
    """
    state: EmailAIState = {
        "system_prompt": system_prompt,
        "user_prompt": user_prompt,
        "provider": provider,
        "rag_section": rag_section,
        "attempts": 0,
        "max_attempts": max(1, min(int(max_attempts), 2)),
        "error": None,
    }
    try:
        from langgraph.graph import StateGraph, START, END
    except Exception:
        result = _fallback_linear(state)
        result["graph_engine"] = "linear-fallback"
        result["prompt_context_attached"] = bool(state.get("rag_section"))
        return result

    def call_model(s: EmailAIState):
        attempts = int(s.get("attempts", 0)) + 1
        try:
            response = s["provider"].generate_json(
                s["system_prompt"] + s.get("rag_section", ""),
                s["user_prompt"],
            )
            return {"response_content": response.content, "attempts": attempts, "error": None}
        except Exception as exc:
            return {"response_content": "", "attempts": attempts, "error": str(exc)[:1000]}

    def validate(s: EmailAIState):
        try:
            candidate = _validate(s.get("response_content", ""))
            return {"candidate": candidate, "error": None}
        except Exception as exc:
            return {"candidate": {}, "error": str(exc)}

    def route(s: EmailAIState):
        if s.get("candidate") and not s.get("error"):
            return "done"
        if int(s.get("attempts", 0)) < int(s.get("max_attempts", 2)):
            return "retry"
        return "failed"

    def repair(s: EmailAIState):
        return {"user_prompt": s["user_prompt"] +
                "\n\nREPAIR INSTRUCTION: Your previous output failed schema validation. "
                "Return exactly one valid JSON object matching the required schema. "
                "No markdown, no explanation, no additional keys."}

    builder = StateGraph(EmailAIState)
    builder.add_node("call_model", call_model)
    builder.add_node("validate", validate)
    builder.add_node("repair", repair)
    builder.add_edge(START, "call_model")
    builder.add_edge("call_model", "validate")
    builder.add_conditional_edges("validate", route, {"done": END, "retry": "repair", "failed": END})
    builder.add_edge("repair", "call_model")
    graph = builder.compile()
    result = graph.invoke(state)
    result["graph_engine"] = "langgraph"
    result["prompt_context_attached"] = bool(state.get("rag_section"))
    return result
