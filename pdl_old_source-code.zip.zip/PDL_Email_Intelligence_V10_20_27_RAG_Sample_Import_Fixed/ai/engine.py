from __future__ import annotations
import json
import os
import re
import time
from datetime import datetime, timezone
from flask import current_app
from db import db, Email, PDL, Engineer, Alert, AIAnalysis, AIModelLog, create_alert, log_event
from .providers.ollama import OllamaProvider
from .providers.disabled import DisabledProvider
from .prompts.email_analysis import SYSTEM_PROMPT
from .rules import classify as rule_classify
from local_ai_agent import analyze_email as local_analyze_email
from intelligence import _latest_message_text, calculate_severity
from .security import sanitize_untrusted_email
from .configuration import get_ai_setting
from .context import build_context, compact_context_for_prompt
from .training import build_training_prompt_section
from .rag import retrieve_training_examples, build_rag_prompt_section, status as rag_status
from .graph import run_email_ai_graph



INTENT_TO_CATEGORY = {
    "RECOGNITION": "recognition",
    "SCHEDULE_REQUEST": "schedule_request",
    "SCHEDULE_CONFIRMATION": "schedule_request",
    "SCHEDULE_CHANGE": "schedule_request",
    "SCHEDULE_CANCELLATION": "schedule_request",
    "STATUS_REQUEST": "update_request",
    "FOLLOW_UP": "follow_up",
    "TECHNICAL_SUPPORT": "technical_support",
    "INFORMATION_REQUEST": "information_request",
    "INFORMATION_ONLY": "information_request",
    "ESCALATION": "escalation",
    "GENERAL": "general",
}


def _executive_context(email) -> list:
    """Return configured manager/executive recipients found in To/CC."""
    try:
        import re as _re
        addresses = set()
        for field in (getattr(email, "recipients", "") or "", getattr(email, "cc", "") or ""):
            addresses.update(
                a.lower() for a in _re.findall(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", field, _re.I)
            )
        sender = str(getattr(email, "sender_email", "") or "").strip().lower()
        executives = []
        for engineer in Engineer.query.filter_by(active=True).all():
            address = str(getattr(engineer, "email", "") or "").strip().lower()
            designation = str(getattr(engineer, "designation", "") or "").lower()
            role = str(getattr(engineer, "contact_role", "engineer") or "engineer").lower()
            leadership_terms = ("manager", "director", "head", "lead", "leadership", "vice president", "vp", "chief", "executive", "gm")
            if address and address in addresses and (
                bool(getattr(engineer, "is_executive", False))
                or role in {"manager", "executive"}
                or any(term in designation for term in leadership_terms)
            ):
                executives.append(engineer)
        # A configured executive sender is also a priority context, even when
        # the executive is not present in To/CC.
        if sender:
            for engineer in Engineer.query.filter_by(active=True).all():
                address = str(getattr(engineer, "email", "") or "").strip().lower()
                if address == sender and (
                    bool(getattr(engineer, "is_executive", False))
                    or str(getattr(engineer, "contact_role", "engineer") or "").lower() in {"manager", "executive"}
                ):
                    executives.append(engineer)
        return list({e.id: e for e in executives}.values())
    except Exception:
        return []


def _create_current_day_priority_alerts(email, result: dict) -> None:
    """Publish final AI intelligence into the same in-app notification pipeline.

    This runs after Email is projected, so notifications reflect the final
    context-aware classification rather than stale sync-time labels.
    """
    # Alert eligibility is based on the newly detected operational condition.
    # Do not reject an alert merely because the source email is older.

    category = str(getattr(email, "email_category", "") or result.get("category") or "").lower()
    level = str(getattr(email, "escalation_level", "") or result.get("escalation_level") or "low").lower()
    severity = str(getattr(email, "severity", "") or result.get("priority") or "normal").lower()
    escalation = bool(result.get("escalation")) or category == "escalation" or level in {"high", "critical"}
    recognition = category == "recognition" or bool(result.get("recognition"))
    if recognition:
        return

    title_subject = (getattr(email, "subject", "") or "(No subject)")[:220]
    action = str(getattr(email, "recommended_action", "") or result.get("recommended_action") or result.get("summary") or "Operational attention required.")[:4000]

    # TAT breach is independent of priority and must remain visible.
    if bool(getattr(email, "tat_breached", False)) and not bool(getattr(email, "monitoring_excluded", False)):
        create_alert(
            email.pdl_id, email.id, "tat_breach", "high",
            f"Action required: TAT breached — {title_subject}",
            action or "Response is overdue; assign or follow up now.",
        )

    # Critical takes precedence over a normal high-priority notification.
    critical = severity == "critical" or level == "critical"
    if critical:
        create_alert(
            email.pdl_id, email.id, "critical_escalation", "critical",
            f"CRITICAL: customer/PDL operational escalation — {title_subject}",
            action,
        )
    elif severity == "high" or escalation:
        create_alert(
            email.pdl_id, email.id, "action_required", "high",
            f"HIGH: operational attention required — {title_subject}",
            action,
        )

    # Explicitly configured managers/executives in To/CC are notification-worthy
    # when the message is customer-facing. This is intentionally separate from
    # severity so leadership visibility is not lost on a routine-but-important
    # customer communication.
    sender_type = str(getattr(email, "sender_type", "") or "").lower()
    if sender_type == "customer":
        executives = _executive_context(email)
        if executives:
            names = ", ".join((e.designation or e.name or e.email) for e in executives[:5])
            create_alert(
                email.pdl_id, email.id, "executive_copy", "high",
                f"Priority: executive copied — {title_subject}",
                f"Configured manager/executive: {names}. Customer communication requires visibility.",
            )

REQUIRED_KEYS = {
    "intent", "sentiment", "priority", "response_required",
    "recognition", "escalation", "summary", "confidence",
}


def _provider():
    name = get_ai_setting("AI_PROVIDER").strip().lower()
    if name in {"local", "ollama"}:
        model = get_ai_setting("AI_MODEL")
        configured_timeout = int(get_ai_setting("AI_TIMEOUT") or 300)
        # Qwen3 8B on a CPU-only Windows workstation can take >90s even for a
        # small request. Never allow an unsafe timeout that guarantees fallback.
        effective_timeout = max(configured_timeout, 300) if model.lower().startswith("qwen3:8b") else max(configured_timeout, 120)
        return OllamaProvider(
            get_ai_setting("AI_BASE_URL"),
            model,
            effective_timeout,
            float(get_ai_setting("AI_TEMPERATURE")),
            get_ai_setting("AI_THINK"),
            get_ai_setting("AI_KEEP_ALIVE"),
        )
    return DisabledProvider()


def health():
    return _provider().health()


def _merge(rule: dict, ai: dict, email, context: dict | None = None) -> dict:
    """Merge AI with deterministic safeguards.

    AI can enrich contextual fields, but it cannot turn a courtesy "thanks"
    into Recognition or downgrade a deterministic critical/escalation signal
    without evidence. Counts and TAT remain application/database facts.
    """
    merged = dict(rule)
    for key, value in ai.items():
        if value not in (None, "", []):
            merged[key] = value

    # The compact Qwen contract returns `intent` rather than a separate
    # category. Project the corrected intent immediately so Live Emails and
    # reports do not remain on the stale sync-time category.
    intent_value = str(merged.get("intent") or "").strip().upper()
    if intent_value in INTENT_TO_CATEGORY:
        merged["category"] = INTENT_TO_CATEGORY[intent_value]

    # Deterministic context guardrails remain the final safety layer.
    # A configured engineer/team member is never customer workload, even if
    # the LLM tries to infer an action request from words such as "urgent",
    # "please", or "required".  Operational impact is still analyzed below
    # and can produce a genuine CRITICAL event notification.
    if getattr(email, "sender_type", "") == "engineer":
        merged["response_required"] = False
        merged["response_requirement"] = "NO_RESPONSE_REQUIRED"
        merged["monitoring_excluded"] = True
        merged["required_action"] = "Monitor operational impact; no customer response is required from this message."
    latest_for_local = _latest_message_text(f"{email.subject or ''}\n{email.body or ''}")
    local = local_analyze_email(email.subject, latest_for_local)
    # Recognition is high precision and deterministic. Never let a model or
    # stale database category create recognition. The current authored message
    # and sender type are authoritative for this metric.
    merged["recognition"] = bool(
        getattr(email, "sender_type", "") == "customer"
        and local.recognition
        and str(rule.get("category") or "").upper() == "RECOGNITION"
        and not bool(rule.get("response_required"))
        and str(rule.get("intent") or "").upper() not in {"SCHEDULE_REQUEST", "SCHEDULE_CONFIRMATION", "SCHEDULE_CHANGE", "SCHEDULE_CANCELLATION"}
    )
    if merged["recognition"]:
        merged["category"] = "RECOGNITION"
    elif str(merged.get("category") or "").upper() == "RECOGNITION":
        merged["category"] = rule.get("category") or "GENERAL"

    # Sentiment conflict guardrail. Weak lexical/LLM evidence must not silently
    # turn a neutral operational request into positive/negative. When the
    # deterministic context classifier is strong and the model disagrees,
    # retain the guardrail and require human review.
    ai_sentiment = str(merged.get("sentiment") or "").lower()
    rule_sentiment = str(rule.get("sentiment") or local.sentiment).lower()
    if ai_sentiment in {"positive", "negative", "concerned", "neutral"}:
        # Strong local evidence is authoritative for sentiment. Qwen enriches
        # ambiguous cases, but it must not turn courtesy/technical facts into
        # positive or negative sentiment.
        strong_local = local.confidence >= 82 or (local.sentiment in {"positive", "negative"} and local.confidence >= 75)
        if strong_local and ai_sentiment != rule_sentiment:
            merged["sentiment"] = rule_sentiment.upper()
            merged["human_review_required"] = True
            merged["reasoning"] = list(merged.get("reasoning") or []) + [
                f"sentiment conflict: model={ai_sentiment}, guardrail={rule_sentiment}"
            ]
        else:
            merged["sentiment"] = ai_sentiment.upper()
    else:
        merged["sentiment"] = rule_sentiment.upper()

    # Keep the strongest operational priority/escalation classification.
    rank = {"LOW": 0, "NORMAL": 1, "HIGH": 2, "CRITICAL": 3}
    rule_priority = str(rule.get("priority", "NORMAL")).upper()
    ai_priority = str(merged.get("priority", "NORMAL")).upper()
    merged["priority"] = ai_priority if rank.get(ai_priority, 1) >= rank.get(rule_priority, 1) else rule_priority

    rule_escalation = str(rule.get("escalation_level", "LOW")).upper()
    ai_escalation = str(merged.get("escalation_level", "LOW")).upper()
    merged["escalation_level"] = ai_escalation if rank.get(ai_escalation, 0) >= rank.get(rule_escalation, 0) else rule_escalation
    merged["escalation"] = bool(merged.get("escalation")) or rule_escalation in {"HIGH", "CRITICAL"}

    # A genuine customer-recognition/courtesy email with no operational action
    # must never remain CRITICAL/HIGH because of stale database values or an
    # overly conservative model response. Real negative/escalation context is
    # excluded by the high-precision recognition detector.
    if merged.get("recognition") and not merged.get("response_required") and not merged.get("escalation"):
        merged["priority"] = "NORMAL"
        merged["escalation_level"] = "LOW"
        merged["customer_risk"] = "LOW"

    # Context-aware operational guardrails. Planned maintenance must not be
    # promoted to active outage merely because the subject/body contains the
    # word "outage". Conversely, an explicit active outage must never remain
    # neutral. These are safety rules around the model, not keyword-only AI.
    signals = (context or {}).get("signals", {})
    planned = bool(signals.get("planned_maintenance"))
    actual_outage = bool(signals.get("actual_outage"))
    blocked = bool(signals.get("customer_blocked"))
    missed = bool(signals.get("customer_meeting_miss"))
    explicit_escalation = bool(signals.get("explicit_escalation"))
    if actual_outage:
        merged["sentiment"] = "CONCERNED" if merged.get("sentiment") in {"NEUTRAL", "POSITIVE"} else merged.get("sentiment")
        merged["priority"] = "CRITICAL"
        merged["escalation_level"] = max((str(merged.get("escalation_level") or "LOW").upper(), "CRITICAL"), key=lambda x: {"LOW":0,"MEDIUM":1,"HIGH":2,"CRITICAL":3}.get(x,0))
        merged["escalation"] = True
    elif planned and not (blocked or missed or explicit_escalation):
        if str(merged.get("priority") or "NORMAL").upper() == "CRITICAL":
            merged["priority"] = "HIGH"
        if str(merged.get("escalation_level") or "LOW").upper() == "CRITICAL":
            merged["escalation_level"] = "HIGH"
        if str(merged.get("sentiment") or "NEUTRAL").upper() == "NEUTRAL":
            merged["sentiment"] = "CONCERNED"
    if (blocked or missed) and not (merged.get("recognition") and not merged.get("response_required")):
        merged["sentiment"] = "CONCERNED" if str(merged.get("sentiment") or "NEUTRAL").upper() == "NEUTRAL" else merged.get("sentiment")
        if actual_outage or (blocked and explicit_escalation):
            merged["priority"] = "CRITICAL"
        elif str(merged.get("priority") or "NORMAL").upper() == "NORMAL":
            merged["priority"] = "HIGH"
    if planned and not actual_outage and not blocked and not missed:
        merged["reasoning"] = list(merged.get("reasoning") or []) + ["context: planned maintenance/downtime language without evidence of an active outage"]
    elif actual_outage:
        merged["reasoning"] = list(merged.get("reasoning") or []) + ["context: active outage/unavailability detected"]
    merged["confidence"] = max(0.0, min(1.0, float(merged.get("confidence", 0.0))))
    threshold = float(get_ai_setting("AI_CONFIDENCE_THRESHOLD"))
    merged["human_review_required"] = bool(merged.get("human_review_required")) or merged["confidence"] < threshold
    return merged



def _parse_model_json(content: str) -> dict:
    """Parse Ollama structured output defensively.

    Some local model builds occasionally wrap otherwise-valid JSON in a code
    fence. Structured-output mode should not require this, but accepting it
    prevents a formatting quirk from turning every Qwen analysis into a
    deterministic fallback.
    """
    text = str(content or "").strip()
    if not text:
        raise ValueError("Ollama returned an empty structured response")
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
        text = re.sub(r"\s*```$", "", text).strip()
    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start < 0 or end <= start:
            raise
        obj = json.loads(text[start:end + 1])
    if not isinstance(obj, dict):
        raise ValueError("Ollama structured response is not a JSON object")
    return obj


def _normalize_ai_candidate(candidate: dict) -> dict:
    """Normalize model enums/numbers before business-rule merging."""
    out = dict(candidate)
    for key in ("sentiment", "category", "customer_frustration", "priority",
                "response_requirement", "escalation_level", "customer_risk",
                "thread_status", "intent"):
        if isinstance(out.get(key), str):
            out[key] = out[key].strip().upper()
    for key in ("confidence", "sentiment_confidence", "recognition_confidence", "deadline_confidence"):
        if key in out:
            try:
                out[key] = max(0.0, min(1.0, float(out[key])))
            except (TypeError, ValueError):
                out[key] = 0.0
    return out

def _ist_today_bounds(now=None):
    """Return UTC [start,end] bounds for the current operational day in IST."""
    from datetime import timedelta
    from zoneinfo import ZoneInfo
    ist = ZoneInfo("Asia/Kolkata")
    now = now or datetime.now(timezone.utc)
    local = now.astimezone(ist)
    start_local = local.replace(hour=0, minute=0, second=0, microsecond=0)
    end_local = start_local + timedelta(days=1)
    return start_local.astimezone(timezone.utc), end_local.astimezone(timezone.utc)

def _needs_model_enrichment(rules: dict, email) -> bool:
    """Decide whether the local model should inspect this email.

    In all_customer mode every customer message is eventually analyzed by the
    local model in the background. Deterministic rules remain the immediate
    safety/metrics layer, so the dashboard/TAT path never waits for Qwen.
    """
    text = _latest_message_text(f"{getattr(email, 'subject', '') or ''}\n{getattr(email, 'body', '') or ''}").lower()
    sender_type = str(getattr(email, "sender_type", "") or "").lower()
    mode = str(get_ai_setting("AI_SCAN_MODE") or "all_customer").strip().lower()
    if sender_type == "customer" and mode == "all_customer":
        return True
    confidence = float(rules.get("confidence") or 0.0)
    category = str(rules.get("category") or "").upper()
    sentiment = str(rules.get("sentiment") or "").upper()
    priority = str(rules.get("priority") or "").upper()
    intent = str(rules.get("intent") or "").upper()
    contextual_terms = (
        "escalat", "disappoint", "frustrat", "unacceptable", "blocked",
        "business impact", "customer impact", "production", "outage",
        "did not join", "didn't join", "no one joined", "nobody joined",
        "excellent", "outstanding", "great work", "appreciat", "recogn",
        "urgent", "critical", "complaint", "still waiting", "downtime",
    )
    high_stakes = priority in {"HIGH", "CRITICAL"} or bool(rules.get("escalation"))
    ambiguous = confidence < 0.55
    semantic_case = category in {"RECOGNITION", "ESCALATION"} or sentiment in {"NEGATIVE", "CONCERNED", "POSITIVE"}
    contextual = any(term in text for term in contextual_terms)
    unclear_intent = intent in {"OTHER", "UNKNOWN", ""}
    return bool(high_stakes or ambiguous or semantic_case or contextual or unclear_intent)


def _rules_success_result(rules: dict) -> dict:
    result = dict(rules)
    result["source"] = "hybrid_rules"
    result["human_review_required"] = bool(result.get("human_review_required"))
    return result



def _project_result_to_email(email, result: dict) -> None:
    """Project the final hybrid/LLM decision onto Email so the UI, reports,
    dashboards and notification logic all consume the same final intelligence.

    This is the critical missing link in earlier releases: AIAnalysis was being
    written successfully, but Email.sentiment/email_category/severity/etc.
    remained the deterministic values created during Outlook sync. As a result
    the AI page could show analysis while the rest of the application appeared
    unchanged.
    """
    def sval(key, default=""):
        value = result.get(key, default)
        return str(value if value is not None else default).strip()

    sender_type = sval("sender_type", getattr(email, "sender_type", "unknown")).lower()
    category_map = {
        "RECOGNITION": "recognition",
        "ESCALATION": "escalation",
        "SCHEDULE_REQUEST": "schedule_request",
        "SCHEDULE_CONFIRMATION": "schedule_request",
        "SCHEDULE_CHANGE": "schedule_request",
        "SCHEDULE_CANCELLATION": "schedule_request",
        "STATUS_REQUEST": "update_request",
        "FOLLOW_UP": "follow_up",
        "TECHNICAL_SUPPORT": "technical_support",
        "INFORMATION_ONLY": "information_request",
        "INFORMATION_REQUEST": "information_request",
        "GENERAL": "general",
    }

    # The compact Qwen contract's authoritative classification field is
    # `intent`.  Older sync-time rules populated Email.email_category first,
    # which could leave a stale "escalation" in Live Emails even after AI had
    # corrected the intent to SCHEDULE_REQUEST.  Prefer a valid AI intent over
    # the pre-AI category, then fall back to category only when intent is absent.
    intent_value = sval("intent", "").upper()
    if intent_value in category_map:
        category = category_map[intent_value]
    else:
        category = sval("category", getattr(email, "email_category", "general")).upper()
        if category in category_map:
            category = category_map[category]
        elif category.lower() not in {
            "recognition", "escalation", "schedule_request", "update_request",
            "follow_up", "technical_support", "information_request", "general"
        }:
            category = getattr(email, "email_category", None) or "general"

    sentiment = sval("sentiment", getattr(email, "sentiment", "neutral")).lower()
    if sentiment not in {"positive", "neutral", "concerned", "negative"}:
        sentiment = getattr(email, "sentiment", "neutral") or "neutral"

    priority = sval("priority", getattr(email, "severity", "normal")).lower()
    if priority == "low":
        severity = "normal"
    elif priority in {"normal", "medium", "high", "critical"}:
        severity = "high" if priority == "medium" else priority
    else:
        severity = getattr(email, "severity", "normal") or "normal"

    # Business rules are authoritative for sender identity.
    if sender_type in {"engineer", "internal"}:
        response_required = False
        monitoring_excluded = True
        exclusion_reason = "Configured engineer / internal communication"
    else:
        response_required = bool(result.get("response_required"))
        monitoring_excluded = not response_required
        exclusion_reason = (
            "Informational / no response required"
            if monitoring_excluded else None
        )

    # A genuine recognition message is never an open workload item unless the
    # latest message also contains a separate actionable request.
    if category == "recognition" and not bool(result.get("escalation")):
        response_required = False
        monitoring_excluded = True
        exclusion_reason = "Customer recognition / appreciation"

    email.email_category = category
    email.sentiment = sentiment
    email.severity = severity
    email.response_required = response_required
    email.monitoring_excluded = monitoring_excluded
    email.exclusion_reason = exclusion_reason

    # Do not retain a stale deterministic escalation level when the final AI
    # intent explicitly says this is a non-escalation request. A signature word
    # such as "escalation" must never win over the reviewed intent.
    ai_escalation = bool(result.get("escalation"))
    level = sval("escalation_level", getattr(email, "escalation_level", "low")).lower()
    if category != "escalation" and not ai_escalation:
        level = "low"
    elif level not in {"low", "medium", "high", "critical"}:
        level = getattr(email, "escalation_level", "low") or "low"
    email.escalation_level = level

    # If the final AI review corrected a false escalation (for example, the word
    # "escalation" appearing only in a signature), retire any alert created by
    # the deterministic fast pass for this email. The email remains auditable;
    # only the now-invalid operational notification is closed.
    if category != "escalation" and not ai_escalation:
        try:
            Alert.query.filter(
                Alert.email_id == email.id,
                Alert.alert_type.in_([
                    "critical_escalation", "action_required",
                    "executive_copy",
                ]),
                Alert.read.is_(False),
            ).update({Alert.read: True}, synchronize_session=False)
        except Exception:
            pass

    # Keep an explainable numeric score aligned with the final level.
    level_score = {"low": 0, "medium": 40, "high": 65, "critical": 90}
    try:
        model_score = int(float(result.get("escalation_score", level_score[level])))
    except (TypeError, ValueError):
        model_score = level_score[level]
    email.escalation_score = max(0, min(100, max(model_score, level_score[level])))

    email.escalation_reasons = (
        " | ".join(result.get("reasoning") or [])
        or email.escalation_reasons
    )
    email.customer_waiting = bool(response_required and not email.responded)
    email.engineer_action_required = bool(response_required and not email.responded)

    if result.get("summary"):
        email.ai_summary = str(result["summary"])[:4000]
    if result.get("recommended_action"):
        email.recommended_action = str(result["recommended_action"])[:4000]

    # Re-evaluate TAT against the final response-required decision.
    if email.responded:
        email.tat_breached = False if email.response_minutes is None else bool(
            email.tat_minutes is not None and email.response_minutes > email.tat_minutes
        )
    elif response_required and email.received_at and email.tat_minutes:
        received = email.received_at
        if received.tzinfo is None:
            received = received.replace(tzinfo=timezone.utc)
        age_minutes = (datetime.now(timezone.utc) - received.astimezone(timezone.utc)).total_seconds() / 60
        email.tat_breached = age_minutes > float(email.tat_minutes)
    else:
        email.tat_breached = False


def analyze_email_id(email_id: int, force: bool = False):
    email = db.session.get(Email, email_id)
    if not email: return None
    existing = AIAnalysis.query.filter_by(email_id=email.id).order_by(AIAnalysis.created_at.desc()).first()
    if existing and existing.status == "COMPLETE" and not force: return existing
    record = AIAnalysis(email_id=email.id, status="PROCESSING", provider=get_ai_setting("AI_PROVIDER"), model=get_ai_setting("AI_MODEL"), prompt_version=get_ai_setting("AI_PROMPT_VERSION") or "v3-context")
    db.session.add(record); db.session.commit()
    started = time.perf_counter(); fallback_used = False; error = None
    context = build_context(email)
    rules = rule_classify(email, context=context)

    # Fast deterministic acceptance: the application must never show an email as
    # "stuck in AI" simply because a local 8B model is slow. Rules are the
    # authoritative safety layer and are a valid hybrid analysis. Qwen then
    # enriches the same record in the background and can replace the result.
    fast_result = _rules_success_result(rules)
    fast_result["context_aware"] = True
    fast_result["analysis_stage"] = "deterministic_fast_pass"
    # Keep the latest analysis visibly PROCESSING while the configured local
    # model is being consulted. Earlier releases marked the record COMPLETE
    # after the fast rules pass and then spent minutes inside Ollama, which
    # made Admin/Live telemetry show 0 processing and made automatic AI appear
    # not to run. The fast result is retained in result_json as the safe
    # deterministic interim result, but status stays PROCESSING until model
    # enrichment completes.
    record.status = "PROCESSING"
    record.provider = "hybrid"
    record.model = "rules-high-confidence"
    record.result_json = json.dumps(fast_result, ensure_ascii=False)
    record.confidence = float(fast_result.get("confidence", 0) or 0)
    record.fallback_used = False
    record.processing_ms = int((time.perf_counter() - started) * 1000)
    record.completed_at = None
    _project_result_to_email(email, fast_result)
    # Do not publish a second notification from the deterministic interim pass.
    # Final notifications are emitted once after the model/final-rule merge.
    db.session.commit()
    subject, subject_flags = sanitize_untrusted_email(email.subject, 3000)
    body, body_flags = sanitize_untrusted_email(email.body, 18000)
    injection_flags = subject_flags + body_flags
    result = rules
    provider = _provider()
    try:
        use_model = provider.name != "rules" and _needs_model_enrichment(rules, email)
        if use_model:
            record.provider = provider.name
            # Persist the processing state before the slow Ollama request so the
            # UI immediately reflects that automatic AI work is actually running.
            db.session.commit()
            members = []
            try:
                if email.pdl_id:
                    pdl = db.session.get(PDL, email.pdl_id)
                    if pdl:
                        members = [
                            {"name": e.name, "email": e.email, "role": getattr(e, "contact_role", "engineer")}
                            for e in (getattr(pdl, "authorized_engineers", None) or [])
                        ][:20]
            except Exception:
                members = []
            # Keep the local CPU model prompt deliberately compact. Long Outlook
            # signatures/quoted history can multiply Qwen3 latency without adding
            # classification value. Context is still preserved in the DB.
            latest_body = _latest_message_text(body)[:2400]
            context_prompt = compact_context_for_prompt(context)
            context_prompt["current"]["message"] = latest_body[:2600]
            context_prompt["rule_hint"] = {
                k: rules.get(k)
                for k in ("intent", "category", "sentiment", "priority", "response_required")
            }
            context_prompt["team_member_sender"] = bool(getattr(email, "sender_type", "") == "engineer")
            prompt = json.dumps(context_prompt, ensure_ascii=False)
            rag_examples = retrieve_training_examples(
                f"{email.subject or ''}\n{latest_body}",
            )
            rag_runtime = rag_status()
            rag_section = build_rag_prompt_section(rag_examples)
            rag_context_source = "semantic_rag" if rag_examples else "none"

            # Keep legacy examples only when semantic RAG has no usable precedent.
            # This is intentionally distinguished from successful semantic RAG in
            # telemetry so an empty/failing vector lookup cannot masquerade as RAG.
            if not rag_examples:
                rag_section = build_training_prompt_section(limit=6)
                if rag_section:
                    rag_context_source = "legacy_training_fallback"
            graph_result = run_email_ai_graph(
                system_prompt=SYSTEM_PROMPT,
                user_prompt=prompt,
                provider=provider,
                rag_section=rag_section,
                max_attempts=2,
            )
            if graph_result.get("error"):
                raise ValueError(str(graph_result["error"]))
            candidate = _normalize_ai_candidate(graph_result.get("candidate") or {})
            if not REQUIRED_KEYS.issubset(candidate):
                missing = sorted(REQUIRED_KEYS - set(candidate))
                raise ValueError("AI response missing required structured fields: " + ", ".join(missing))
            candidate["rag_used"] = bool(rag_examples)
            candidate["rag_context_source"] = rag_context_source
            candidate["rag_prompt_attached"] = bool(graph_result.get("prompt_context_attached"))
            candidate["rag_available"] = bool(rag_runtime.get("available"))
            candidate["rag_indexed_examples"] = int(rag_runtime.get("indexed_examples") or 0)
            candidate["rag_error"] = rag_runtime.get("error")
            candidate["rag_examples"] = [
                {
                    "example_id": x.get("example_id"),
                    "source": x.get("source"),
                    "example_key": x.get("example_key"),
                    "score": x.get("score"),
                    "labels": x.get("labels"),
                }
                for x in rag_examples
            ]
            candidate["graph_engine"] = graph_result.get("graph_engine", "linear-fallback")
            # Keep the model contract small and derive secondary operational
            # fields locally. This improves 8B-model speed and reliability.
            candidate.setdefault("category", rules.get("category") or "GENERAL")
            candidate.setdefault("sentiment_evidence", "")
            candidate.setdefault("customer_frustration",
                                 "HIGH" if candidate.get("sentiment") == "NEGATIVE" else
                                 "MEDIUM" if candidate.get("sentiment") == "CONCERNED" else "LOW")
            candidate.setdefault("escalation_level",
                                 "CRITICAL" if candidate.get("escalation") and candidate.get("priority") == "CRITICAL" else
                                 "HIGH" if candidate.get("escalation") else "LOW")
            candidate.setdefault("customer_risk",
                                 "CRITICAL" if candidate.get("priority") == "CRITICAL" else
                                 "HIGH" if candidate.get("escalation") else
                                 rules.get("customer_risk") or "LOW")
            result = _merge(rules, candidate, email, context)
            record.model = getattr(provider, "model", get_ai_setting("AI_MODEL"))
        else:
            # A high-confidence deterministic classification is a successful
            # hybrid decision, not an AI failure/fallback. In this path there is
            # no model work, so it is safe to complete the analysis immediately.
            result = _rules_success_result(rules)
            fallback_used = False
            record.provider = "hybrid"
            record.model = "rules-high-confidence"
    except Exception as exc:
        # Model enrichment failed; keep the application correct and responsive
        # with deterministic guardrails while recording a single diagnostic.
        fallback_used = True
        error = str(exc)
        result = _rules_success_result(rules)
    # Keep lightweight context provenance with the AI result so the evaluation
    # page can distinguish context-aware analysis from legacy/rules analysis.
    result["context_aware"] = True
    result["context_message_count"] = int(len((context.get("thread", {}).get("previous_messages", []) or [])) + 1)
    result["context_signals"] = {
        k: bool(v) for k, v in (context.get("signals", {}) or {}).items()
        if isinstance(v, bool)
    }
    processing_ms = int((time.perf_counter() - started) * 1000)
    record.status = "COMPLETE"; record.result_json = json.dumps(result, ensure_ascii=False)
    record.confidence = float(result.get("confidence", 0)); record.human_review_required = bool(result.get("human_review_required"))
    record.fallback_used = fallback_used; record.processing_ms = processing_ms; record.error = error
    record.prompt_injection_detected = bool(injection_flags); record.injection_flags = " | ".join(injection_flags[:10]) or None
    record.completed_at = datetime.now(timezone.utc)

    # IMPORTANT: publish the final intelligence result to the Email row before
    # committing. All dashboard/report/list/notification queries use Email;
    # leaving AIAnalysis isolated makes the AI appear to do nothing.
    _project_result_to_email(email, result)
    _create_current_day_priority_alerts(email, result)

    log = AIModelLog(email_id=email.id, provider=record.provider, model=record.model, prompt_version=record.prompt_version,
                     confidence=record.confidence, processing_ms=processing_ms, fallback_used=fallback_used, error=error)
    db.session.add(log)
    # Final notification publication is handled by _create_current_day_priority_alerts above.
    db.session.commit()
    return record
