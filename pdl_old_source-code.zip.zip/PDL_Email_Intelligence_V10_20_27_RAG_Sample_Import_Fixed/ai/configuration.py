from __future__ import annotations
import os

# Recommended local candidates for this application. Keep these configurable;
# benchmark on representative PDL mail before selecting a production model.
MODEL_PRESETS = {
    "qwen3:8b": {
        "label": "Qwen3 8B — recommended benchmark candidate",
        "family": "Qwen3",
        "size": "8B",
        "structured": True,
        "thinking_capable": True,
    },
    "llama3.1:8b": {
        "label": "Llama 3.1 8B — benchmark candidate",
        "family": "Llama 3.1",
        "size": "8B",
        "structured": True,
        "thinking_capable": False,
    },
    "mistral:7b": {
        "label": "Mistral 7B — benchmark candidate",
        "family": "Mistral",
        "size": "7B",
        "structured": True,
        "thinking_capable": False,
    },
    "qwen2.5:7b": {
        "label": "Qwen2.5 7B — current stable candidate",
        "family": "Qwen2.5",
        "size": "7B",
        "structured": True,
        "thinking_capable": False,
    },
}

DEFAULTS = {
    "AI_PROVIDER": "local",
    "AI_MODEL": "qwen3:8b",
    "AI_BASE_URL": "http://127.0.0.1:11434",
    "AI_TIMEOUT": "300",
    "AI_TEMPERATURE": "0.0",
    "AI_CONFIDENCE_THRESHOLD": "0.72",
    "AI_FALLBACK_MODE": "rules",
    # Qwen3 and other thinking-capable models can be explicitly controlled.
    # Classification is intentionally run without a visible reasoning trace.
    "AI_THINK": "false",
    "AI_KEEP_ALIVE": "60m",
    "AI_MAX_TOKENS": "256",
    "AI_NUM_CTX": "8192",
    "AI_SCAN_MODE": "all_customer",
    "AI_QUEUE_LIMIT": "4",
    "AI_PROMPT_VERSION": "v5-rag-langgraph",
    # Local-only AI/RAG controls. These defaults never download models or
    # send email content to a remote service.
    "AI_LOCAL_ONLY": "true",
    "AI_RAG_ENABLED": "true",
    "AI_RAG_TOP_K": "4",
    "AI_RAG_MIN_SCORE": "0.55",
    "AI_RAG_PATH": "instance/chroma",
    "AI_EMBEDDING_MODEL_PATH": "models/all-MiniLM-L6-v2",
    "AI_EMBEDDING_DEVICE": "cpu",
    "AI_RAG_AUTO_INDEX": "true",
    "AI_RAG_SYNC_INTERVAL_SECONDS": "60",
}


def get_ai_setting(name: str) -> str:
    try:
        from db import get_sync_state
        value = get_sync_state(f"ai:{name}")
        if value not in (None, ""):
            return str(value)
    except Exception:
        pass
    return os.getenv(name, DEFAULTS.get(name, ""))


def all_settings():
    return {key: get_ai_setting(key) for key in DEFAULTS}
