from __future__ import annotations

import hashlib
import json
import os
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .configuration import get_ai_setting

_LOCK = threading.RLock()
_MODEL = None
_CLIENT = None
_COLLECTION = None
_LAST_ERROR: str | None = None
_LAST_ERROR_AT: str | None = None
_LAST_SYNC_AT_MONOTONIC = 0.0
_LAST_SYNC_RESULT: dict[str, Any] = {
    "ok": True,
    "indexed": 0,
    "updated": 0,
    "deleted": 0,
    "unchanged": 0,
    "skipped": True,
}


def _enabled() -> bool:
    return str(get_ai_setting("AI_RAG_ENABLED") or "true").strip().lower() not in {"0", "false", "no", "off"}


def _local_only() -> bool:
    return str(get_ai_setting("AI_LOCAL_ONLY") or "true").strip().lower() not in {"0", "false", "no", "off"}


def _root() -> Path:
    return Path(__file__).resolve().parent.parent


def _rag_path() -> Path:
    raw = get_ai_setting("AI_RAG_PATH") or "instance/chroma"
    path = Path(raw)
    if not path.is_absolute():
        path = _root() / path
    path.mkdir(parents=True, exist_ok=True)
    return path


def _model_path() -> Path:
    raw = get_ai_setting("AI_EMBEDDING_MODEL_PATH") or "models/all-MiniLM-L6-v2"
    path = Path(raw)
    if not path.is_absolute():
        path = _root() / path
    return path


def _record_error(exc: Exception | str) -> None:
    global _LAST_ERROR, _LAST_ERROR_AT
    _LAST_ERROR = str(exc)[:1000]
    _LAST_ERROR_AT = datetime.now(timezone.utc).isoformat()


def _clear_error() -> None:
    global _LAST_ERROR, _LAST_ERROR_AT
    _LAST_ERROR = None
    _LAST_ERROR_AT = None


def _load():
    global _MODEL, _CLIENT, _COLLECTION
    with _LOCK:
        if _MODEL is not None and _COLLECTION is not None:
            return _MODEL, _COLLECTION
        if not _enabled():
            raise RuntimeError("Local RAG is disabled")
        try:
            import chromadb
            from chromadb.config import Settings
            from sentence_transformers import SentenceTransformer
        except Exception as exc:
            raise RuntimeError(f"RAG dependencies are not installed: {exc}") from exc

        model_path = _model_path()
        if not model_path.exists():
            raise RuntimeError(
                f"Local embedding model not found: {model_path}. "
                "Install/stage all-MiniLM-L6-v2 locally before enabling RAG."
            )

        # Never allow the runtime to fetch a model from the internet.
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"
        _MODEL = SentenceTransformer(
            str(model_path),
            device=(get_ai_setting("AI_EMBEDDING_DEVICE") or "cpu"),
            local_files_only=True,
        )
        _CLIENT = chromadb.PersistentClient(
            path=str(_rag_path()),
            settings=Settings(anonymized_telemetry=False),
        )
        _COLLECTION = _CLIENT.get_or_create_collection(
            name="pdl_validated_training",
            metadata={"hnsw:space": "cosine", "security": "local_only"},
        )
        return _MODEL, _COLLECTION


def _document(row, payload: dict[str, Any], labels: dict[str, Any]) -> str:
    # Do not embed labels themselves; that can leak the answer into retrieval.
    # Only semantic email content and coarse sender context are embedded.
    return "\n".join([
        f"Subject: {str(payload.get('subject') or '')[:500]}",
        f"Sender type: {str(payload.get('sender_type') or '')[:40]}",
        f"Message: {str(payload.get('message') or '')[:5000]}",
    ])


def _row_parts(row) -> tuple[dict[str, Any], dict[str, Any], str]:
    try:
        payload = json.loads(row.example_json or "{}")
    except Exception:
        payload = {}
    try:
        labels = json.loads(row.labels_json or "{}")
    except Exception:
        labels = {}
    return payload, labels, _document(row, payload, labels)


def _fingerprint(text: str, labels: dict[str, Any]) -> str:
    # Include the fields that affect retrieval output. A label-only edit must
    # update Chroma metadata even when the embedded email text is unchanged.
    material = {
        "document": text,
        "labels": {
            k: labels.get(k)
            for k in (
                "intent", "sentiment", "priority", "category",
                "response_required", "recognition", "escalation",
            )
        },
    }
    raw = json.dumps(material, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _row_source(row) -> str:
    return "upload" if row.__class__.__name__ == "AIUploadedTrainingSample" else "email"


def _storage_id(row) -> str:
    return f"training:{_row_source(row)}:{int(row.id)}"


def index_training_example(row) -> dict[str, Any]:
    global _LAST_SYNC_AT_MONOTONIC
    try:
        model, collection = _load()
        payload, labels, text = _row_parts(row)
        fingerprint = _fingerprint(text, labels)
        embedding = model.encode(text, normalize_embeddings=True).tolist()
        metadata = {
            "example_id": int(row.id),
            "source": _row_source(row),
            "active": True,
            "fingerprint": fingerprint,
            "intent": str(labels.get("intent") or "GENERAL")[:80],
            "sentiment": str(labels.get("sentiment") or "neutral")[:40],
            "priority": str(labels.get("priority") or "normal")[:40],
            "category": str(labels.get("category") or "general")[:80],
            "response_required": bool(labels.get("response_required")),
            "recognition": bool(labels.get("recognition")),
            "escalation": bool(labels.get("escalation")),
        }
        collection.upsert(
            ids=[_storage_id(row)],
            documents=[text],
            embeddings=[embedding],
            metadatas=[metadata],
        )
        # A direct save/import may have happened after the last throttled sync.
        # Force the next retrieval to reconcile stale/deactivated legacy IDs.
        _LAST_SYNC_AT_MONOTONIC = 0.0
        _clear_error()
        return {
            "id": int(row.id), "source": _row_source(row),
            "indexed": True, "fingerprint": fingerprint,
        }
    except Exception as exc:
        _record_error(exc)
        raise


def sync_training_examples(force: bool = False) -> dict[str, Any]:
    """Synchronize active DB training rows with Chroma.

    Unlike a count-only check, this detects:
      * newly created examples,
      * edited email text,
      * edited labels,
      * deactivated/deleted examples.

    Synchronization is throttled because retrieval can run once per email. Set
    AI_RAG_SYNC_INTERVAL_SECONDS=0 to check on every retrieval.
    """
    global _LAST_SYNC_AT_MONOTONIC, _LAST_SYNC_RESULT

    if not _enabled():
        result = {"ok": True, "disabled": True, "skipped": True}
        _LAST_SYNC_RESULT = result
        return result

    try:
        interval = max(0.0, float(get_ai_setting("AI_RAG_SYNC_INTERVAL_SECONDS") or 60))
    except (TypeError, ValueError):
        interval = 60.0

    now = time.monotonic()
    with _LOCK:
        if not force and interval > 0 and (now - _LAST_SYNC_AT_MONOTONIC) < interval:
            cached = dict(_LAST_SYNC_RESULT)
            cached["skipped"] = True
            return cached

        try:
            from db import AITrainingExample, AIUploadedTrainingSample

            _, collection = _load()
            rows = (
                AITrainingExample.query.filter_by(active=True).order_by(AITrainingExample.id.asc()).all()
                + AIUploadedTrainingSample.query.filter_by(active=True).order_by(AIUploadedTrainingSample.id.asc()).all()
            )
            desired_ids = {_storage_id(row) for row in rows}

            existing = collection.get(include=["metadatas"])
            existing_ids = list(existing.get("ids") or [])
            existing_metas = list(existing.get("metadatas") or [])
            existing_map = {
                str(item_id): (meta or {})
                for item_id, meta in zip(existing_ids, existing_metas)
                if str(item_id).startswith("training:")
            }

            indexed = 0
            updated = 0
            unchanged = 0
            for row in rows:
                item_id = _storage_id(row)
                _, labels, text = _row_parts(row)
                expected_fingerprint = _fingerprint(text, labels)
                current = existing_map.get(item_id)

                if current is None:
                    index_training_example(row)
                    indexed += 1
                elif str(current.get("fingerprint") or "") != expected_fingerprint:
                    index_training_example(row)
                    updated += 1
                else:
                    unchanged += 1

            stale_ids = sorted(set(existing_map) - desired_ids)
            if stale_ids:
                collection.delete(ids=stale_ids)

            _LAST_SYNC_AT_MONOTONIC = now
            _LAST_SYNC_RESULT = {
                "ok": True,
                "indexed": indexed,
                "updated": updated,
                "deleted": len(stale_ids),
                "unchanged": unchanged,
                "active_db_examples": len(rows),
                "collection_examples": int(collection.count()),
                "skipped": False,
            }
            _clear_error()
            return dict(_LAST_SYNC_RESULT)
        except Exception as exc:
            _record_error(exc)
            _LAST_SYNC_AT_MONOTONIC = now
            _LAST_SYNC_RESULT = {
                "ok": False,
                "indexed": 0,
                "updated": 0,
                "deleted": 0,
                "unchanged": 0,
                "skipped": False,
                "error": str(exc)[:1000],
            }
            return dict(_LAST_SYNC_RESULT)


def index_all_training_examples() -> dict[str, Any]:
    # Preserve the public API's historical `indexed == active row count` meaning
    # while exposing how many records were actually inserted/updated.
    result = sync_training_examples(force=True)
    if result.get("ok"):
        result = dict(result)
        result["newly_indexed"] = int(result.get("indexed") or 0)
        result["indexed"] = int(result.get("active_db_examples") or 0)
    return result


def retrieve_training_examples(
    text: str,
    top_k: int | None = None,
    min_score: float | None = None,
) -> list[dict[str, Any]]:
    if not _enabled() or not text.strip():
        return []

    sync_result: dict[str, Any] | None = None
    try:
        model, collection = _load()

        if str(get_ai_setting("AI_RAG_AUTO_INDEX") or "true").strip().lower() not in {"0", "false", "no", "off"}:
            # A sync failure does not prevent retrieval from the last known-good
            # Chroma collection. The failure remains visible through status().
            sync_result = sync_training_examples(force=False)

        count = int(top_k or get_ai_setting("AI_RAG_TOP_K") or 4)
        threshold = float(
            min_score
            if min_score is not None
            else (get_ai_setting("AI_RAG_MIN_SCORE") or 0.55)
        )
        count = max(1, min(count, 8))

        collection_count = int(collection.count())
        if collection_count <= 0:
            if not sync_result or sync_result.get("ok", True):
                _clear_error()
            return []

        result = collection.query(
            query_embeddings=[model.encode(text[:7000], normalize_embeddings=True).tolist()],
            n_results=min(count, collection_count),
            include=["documents", "metadatas", "distances"],
        )
        docs = (result.get("documents") or [[]])[0]
        metas = (result.get("metadatas") or [[]])[0]
        distances = (result.get("distances") or [[]])[0]

        output: list[dict[str, Any]] = []
        for doc, meta, distance in zip(docs, metas, distances):
            score = max(0.0, min(1.0, 1.0 - float(distance)))
            if score < threshold:
                continue
            output.append({
                "score": round(score, 4),
                "example_id": int((meta or {}).get("example_id") or 0),
                "source": str((meta or {}).get("source") or "email"),
                "example_key": f"{str((meta or {}).get('source') or 'email')}:{int((meta or {}).get('example_id') or 0)}",
                "document": str(doc or "")[:6000],
                "labels": {
                    k: (meta or {}).get(k)
                    for k in (
                        "intent", "sentiment", "priority", "category",
                        "response_required", "recognition", "escalation",
                    )
                },
            })

        if not sync_result or sync_result.get("ok", True):
            _clear_error()
        return output
    except Exception as exc:
        # RAG is an enrichment layer. It must never prevent deterministic or
        # local-model analysis from completing, but failures must be observable.
        _record_error(exc)
        return []


def build_rag_prompt_section(examples: list[dict[str, Any]]) -> str:
    if not examples:
        return ""
    compact = []
    for item in examples:
        compact.append({
            "similarity": item.get("score"),
            "validated_example": item.get("document"),
            "validated_labels": item.get("labels"),
        })
    return (
        "\n\nRETRIEVED HUMAN-VALIDATED PRECEDENTS\n"
        "These are semantically similar examples previously corrected by a human. "
        "Use them as precedent, not as facts about the current email. If the current "
        "message differs, follow the current message and explicit rules. Never copy "
        "names, dates, systems, customers, or other facts from an example.\n"
        + json.dumps(compact, ensure_ascii=False)
    )


def status(validate_runtime: bool = False) -> dict[str, Any]:
    """Return RAG diagnostics without making RAG a hard dependency.

    validate_runtime=True additionally forces the embedding model/collection load,
    which is useful for an Admin diagnostics endpoint or startup self-test.
    """
    enabled = _enabled()
    model_path = _model_path()
    dep_error: str | None = None
    dependencies_available = False
    collection_available = False
    count = 0

    if enabled:
        try:
            import chromadb  # noqa: F401
            import sentence_transformers  # noqa: F401
            dependencies_available = True

            if validate_runtime:
                _load()

            from chromadb.config import Settings
            client = _CLIENT or chromadb.PersistentClient(
                path=str(_rag_path()),
                settings=Settings(anonymized_telemetry=False),
            )
            collection = _COLLECTION or client.get_or_create_collection(
                name="pdl_validated_training",
                metadata={"hnsw:space": "cosine", "security": "local_only"},
            )
            count = int(collection.count())
            collection_available = True
        except Exception as exc:
            dep_error = str(exc)[:1000]
            _record_error(exc)

    model_staged = model_path.exists()
    config_error = None
    if enabled and not model_staged:
        config_error = f"Local embedding model not found: {model_path}"
    runtime_error = dep_error or _LAST_ERROR or config_error
    available = bool(enabled and dependencies_available and model_staged and collection_available and not dep_error)
    database_examples = None
    try:
        from .training import training_example_count
        database_examples = int(training_example_count())
    except Exception:
        pass

    return {
        "enabled": enabled,
        "local_only": _local_only(),
        "available": available,
        "dependencies_available": dependencies_available,
        "model_staged": model_staged,
        "runtime_loaded": bool(_MODEL is not None and _COLLECTION is not None),
        "embedding_model": str(model_path),
        "embedding_device": str(get_ai_setting("AI_EMBEDDING_DEVICE") or "cpu"),
        "rag_path": str(_rag_path()),
        "collection": "pdl_validated_training",
        "indexed_examples": count,
        "database_examples": database_examples,
        "top_k": int(get_ai_setting("AI_RAG_TOP_K") or 4),
        "min_score": float(get_ai_setting("AI_RAG_MIN_SCORE") or 0.55),
        "last_sync": dict(_LAST_SYNC_RESULT),
        "last_runtime_error": runtime_error,
        "last_runtime_error_at": _LAST_ERROR_AT,
        # Keep the legacy key for callers already expecting status()["error"].
        "error": runtime_error,
    }
