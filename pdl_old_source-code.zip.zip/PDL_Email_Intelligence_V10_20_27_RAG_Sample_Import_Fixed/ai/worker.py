from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor
from threading import Lock, Thread, Event

# Ollama on a CPU-only Windows workstation is intentionally serialized. Multiple
# Qwen3 requests compete for the same CPU/model and are usually slower, not faster.
# V10.20.17 keeps one model worker but continuously refills it so a single
# enqueue call cannot strand the remaining customer emails in "unanalyzed".
_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="pdl-ai")
_pending = set()
_active = set()
_lock = Lock()
_dispatcher_started = False
_dispatcher_lock = Lock()
_dispatcher_stop = Event()


def stats():
    """Return accurate in-process queue telemetry for the UI."""
    with _lock:
        processing = len(_active)
        queued = len(_pending - _active)
        return {
            "pending": processing + queued,
            "processing": processing,
            "queued": queued,
            "workers": 1,
        }


def _pump_next_batch(app):
    """Refill the AI worker after a task completes.

    The previous implementation called enqueue_unanalyzed_ai() only once after
    Outlook sync. With a queue limit of 8, only the first batch was ever sent to
    Ollama; after those tasks finished the UI correctly showed 0/0 even though
    hundreds of customer emails remained. Refill from the same application
    query after every completion. No email content is logged or persisted here.
    """
    try:
        with app.app_context():
            from server import enqueue_unanalyzed_ai
            enqueue_unanalyzed_ai()
    except Exception as exc:
        # Never make automatic queue failures invisible. The queue can recover on
        # the next dispatcher tick, but the event must be diagnosable without
        # requiring the user to click "Analyze with AI" manually.
        try:
            from db import log_event
            with app.app_context():
                log_event("WARN", "ai_queue", "Automatic AI queue refill failed; dispatcher will retry.", str(exc))
        except Exception:
            pass


def enqueue(app, email_id: int, force: bool = False):
    with _lock:
        if email_id in _pending:
            return False
        _pending.add(email_id)

    def run():
        with _lock:
            _active.add(email_id)
        try:
            with app.app_context():
                from .engine import analyze_email_id
                analyze_email_id(email_id, force=force)
        except Exception as exc:
            # Never let a worker exception disappear silently. A failed task must
            # be visible in Events & Logs and must not leave a stale PROCESSING row.
            try:
                from db import db, log_event, AIAnalysis
                with app.app_context():
                    row = (AIAnalysis.query.filter_by(email_id=email_id)
                           .order_by(AIAnalysis.created_at.desc()).first())
                    if row and row.status == "PROCESSING":
                        row.status = "ERROR"
                        row.error = str(exc)[:4000]
                        db.session.commit()
                    log_event("ERROR", "ai_worker", f"AI worker failed for email {email_id}.", str(exc))
            except Exception:
                pass
        finally:
            try:
                from db import db
                db.session.remove()
            except Exception:
                pass
            with _lock:
                _active.discard(email_id)
                _pending.discard(email_id)
            # Keep the single CPU worker busy with the next batch. This is
            # deliberately outside the app context used by the completed job.
            _pump_next_batch(app)

    _executor.submit(run)
    return True


def start_dispatcher(app, interval_seconds: int = 5):
    """Start one lightweight AI queue dispatcher for the application.

    Sync/import code can finish before a background worker gets its first
    queue refill, and older builds relied too heavily on the sync request to
    seed the queue.  This dispatcher is intentionally cheap: it only queries
    the database for eligible customer mail and schedules work; Ollama itself
    remains serialized by the single executor.
    """
    global _dispatcher_started
    with _dispatcher_lock:
        if _dispatcher_started:
            return
        _dispatcher_started = True

    def loop():
        while not _dispatcher_stop.is_set():
            try:
                with app.app_context():
                    from server import enqueue_unanalyzed_ai
                    enqueue_unanalyzed_ai()
            except Exception as exc:
                try:
                    from db import log_event
                    with app.app_context():
                        log_event("WARN", "ai_dispatcher", "Automatic AI dispatcher tick failed; retrying.", str(exc))
                except Exception:
                    pass
            _dispatcher_stop.wait(max(2, int(interval_seconds)))

    Thread(target=loop, name="pdl-ai-dispatcher", daemon=True).start()
