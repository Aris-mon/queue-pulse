from __future__ import annotations

import re
from datetime import timezone
from typing import Any

from intelligence import _latest_message_text, clean_text, strip_signature


def _fmt_dt(value):
    if not value:
        return None
    try:
        v = value if value.tzinfo else value.replace(tzinfo=timezone.utc)
        return v.isoformat()
    except Exception:
        return str(value)


def _thread_key(email):
    cid = clean_text(getattr(email, "conversation_id", ""))
    if cid:
        return ("conversation", cid)
    subject = clean_text(getattr(email, "subject", "")).lower()
    subject = re.sub(r"^(re|fw|fwd)\s*:\s*", "", subject, flags=re.I)
    return ("subject", f"{getattr(email, 'pdl_id', None)}:{subject}")


def _clean_message(email):
    text = _latest_message_text(f"{getattr(email, 'subject', '') or ''}\n{getattr(email, 'body', '') or ''}")
    return clean_text(strip_signature(text))


def _operational_signals(subject: str, body: str) -> dict[str, Any]:
    text = clean_text(f"{subject} {body}").lower()
    planned = any(x in text for x in (
        "planned downtime", "downtime required", "required downtime",
        "is downtime required", "if downtime is required", "will there be downtime", "need downtime",
        "maintenance window", "planned outage", "outage window",
        "service interruption window", "maintenance activity",
    ))
    actual = any(x in text for x in (
        "production is down", "production down", "service is down",
        "service unavailable", "service is unavailable", "system is down",
        "system unavailable", "currently down", "currently unavailable",
        "complete outage", "major outage", "production outage",
        "active outage", "customers are unable", "customer is unable",
        "business is stopped", "business stopped", "data loss", "data corruption",
        "security breach", "security incident",
    ))
    explicit_outage = bool(re.search(r"\boutage\b", text))
    blocked = any(x in text for x in (
        "customer completely blocked", "completely blocked", "cannot proceed",
        "can't proceed", "unable to proceed", "deployment is blocked",
        "production is blocked", "blocking the customer", "business impact",
        "customer impact",
    ))
    missed_event = any(x in text for x in (
        "did not join", "didn't join", "failed to join", "no one joined",
        "nobody joined", "missed the call", "missed customer call",
        "failed to attend",
    ))
    escalation = any(x in text for x in (
        "please escalate", "escalate this", "escalate the issue",
        "escalate to management", "raise this to management",
        "formal escalation", "formal complaint", "customer escalation",
    ))
    urgency = any(x in text for x in (
        "urgent", "urgently", "asap", "immediately", "critical priority",
        "p1", "sev1", "time sensitive", "right away",
    ))
    request = any(x in text for x in (
        "please confirm", "please advise", "please provide", "please schedule",
        "please arrange", "please share", "could you", "can you", "would you",
        "please clarify", "need clarification", "any update", "status update",
        "follow up", "following up", "reminder", "schedule", "availability",
    )) or "?" in text
    return {
        "planned_maintenance": planned,
        "actual_outage": actual,
        "explicit_outage_term": explicit_outage,
        "customer_blocked": blocked,
        "customer_meeting_miss": missed_event,
        "explicit_escalation": escalation,
        "urgent": urgency,
        "action_request": request,
    }


def build_context(email, max_previous: int = 4) -> dict[str, Any]:
    from db import db, Email, PDL
    """Build compact operational context for AI without blocking the ingestion path.

    Facts are obtained from the database/application. The model is only asked to
    interpret meaning. This prevents Qwen from guessing sender identity, response
    state, PDL membership or TAT facts.
    """
    current = _clean_message(email)
    key_type, key_value = _thread_key(email)
    q = Email.query.filter(Email.id != email.id, Email.pdl_id == email.pdl_id)
    if key_type == "conversation":
        q = q.filter(Email.conversation_id == key_value)
    else:
        # Subject fallback is deliberately conservative.
        normalized = re.sub(r"^(re|fw|fwd)\s*:\s*", "", key_value.split(":", 1)[-1], flags=re.I).strip().lower()
        rows = q.order_by(Email.received_at.desc()).limit(40).all()
        rows = [r for r in rows if re.sub(r"^(re|fw|fwd)\s*:\s*", "", clean_text(r.subject).lower()).strip() == normalized]
        rows = rows[:max_previous]
    if key_type == "conversation":
        rows = q.order_by(Email.received_at.desc()).limit(max_previous).all()
    rows = list(reversed(rows))

    previous = []
    for row in rows:
        previous.append({
            "received_at": _fmt_dt(row.received_at),
            "sender_type": row.sender_type,
            "sender_name": row.sender_name,
            "sender_email": row.sender_email,
            "subject": clean_text(row.subject)[:220],
            "message": _clean_message(row)[:1200],
            "responded": bool(row.responded),
            "response_required": bool(row.response_required),
            "first_response_at": _fmt_dt(row.first_response_at),
            "response_engineer": row.response_engineer_name,
        })

    pdl_info = {}
    try:
        pdl = db.session.get(PDL, email.pdl_id) if email.pdl_id else None
        if pdl:
            pdl_info = {
                "name": pdl.name,
                "team": pdl.team,
                "tat_minutes": pdl.tat_minutes,
                "members": [
                    {"name": e.name, "email": e.email}
                    for e in (getattr(pdl, "authorized_engineers", None) or [])
                    if getattr(e, "email", None)
                ][:30],
            }
    except Exception:
        pdl_info = {}

    context = {
        "current": {
            "received_at": _fmt_dt(email.received_at),
            "sender_type": email.sender_type,
            "sender_name": email.sender_name,
            "sender_email": email.sender_email,
            "sender_domain": email.sender_domain,
            "subject": clean_text(email.subject)[:500],
            "message": current[:5000],
            "responded": bool(email.responded),
            "response_required": bool(email.response_required),
            "first_response_at": _fmt_dt(email.first_response_at),
            "last_response_at": _fmt_dt(email.last_response_at),
            "response_engineer": email.response_engineer_name,
            "response_minutes": email.response_minutes,
            "tat_minutes": email.tat_minutes,
            "tat_breached": bool(email.tat_breached),
        },
        "pdl": pdl_info,
        "thread": {
            "key_type": key_type,
            "message_count_in_context": len(previous) + 1,
            "previous_messages": previous,
        },
        "signals": _operational_signals(email.subject or "", current),
    }
    return context


def compact_context_for_prompt(context: dict[str, Any]) -> dict[str, Any]:
    """Keep the model prompt bounded while preserving high-value facts."""
    c = context.get("current", {})
    p = context.get("pdl", {})
    t = context.get("thread", {})
    return {
        "current": c,
        "pdl": {
            "name": p.get("name"), "team": p.get("team"),
            "tat_minutes": p.get("tat_minutes"),
            "members": p.get("members", [])[:20],
        },
        "thread": {
            "previous_messages": t.get("previous_messages", [])[-4:],
        },
        "signals": context.get("signals", {}),
    }
