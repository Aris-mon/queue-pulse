from __future__ import annotations
import re

INJECTION_PATTERNS = (
    r"ignore (all|any|the) (previous|prior|system) instructions",
    r"system prompt", r"developer message", r"reveal .*prompt",
    r"act as .*administrator", r"send (this|an) email", r"delete .*email",
)


def sanitize_untrusted_email(value: str | None, max_chars: int = 18000) -> tuple[str, list[str]]:
    text = str(value or "").replace("\x00", " ")[:max_chars]
    flags = [p for p in INJECTION_PATTERNS if re.search(p, text, flags=re.I)]
    return text, flags
